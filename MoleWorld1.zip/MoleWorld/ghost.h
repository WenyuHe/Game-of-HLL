#ifndef GHOST_H
#define GHOST_H
#include "soldier.h"
#include "weapon.h"
class Ghost:public Soldier
{
public:
    Ghost();
    ~Ghost();
    Weapon usefire();
};

#endif // GHOST_H
