#include "world.h"
#include "icon.h"
#include <iostream>
#include <fstream>

using namespace std;
void World::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5
    moledead=false;
    ghostdead=false;

    ifstream fp(mapFile);
    string type;
    int x,y;

    fp>>type>>x>>y;
    this->_mole.initObj(type);
    this->_mole.setPosX(x);
    this->_mole.setPosY(y);
    this->_mole.initpower(10);
    this->_moleblood.initblood(1000);

    fp>>type>>x>>y;
    this->_ghost.initObj(type);
    this->_ghost.setPosX(x);
    this->_ghost.setPosY(y);
    this->_ghost.initpower(20);
    this->_ghostblood.initblood(1000);

    fp>>type>>x>>y;
    this->_moleblood.setPosX(x);
    this->_moleblood.setPosY(y);

    fp>>type>>x>>y;
    this->_ghostblood.setPosX(x);
    this->_ghostblood.setPosY(y);
}


void World::show(QPainter * painter){
    vector<Weapon>::iterator it;
    for(it=this->_water.begin();it!=this->_water.end();it++){
        (*it).show(painter);
        /*QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\water.mp3"));
        player->setVolume(30);
        player->play();*/
    }
    for(it=this->_fire.begin();it!=this->_fire.end();it++){
        (*it).show(painter);
    }
    for(it=this->_indian.begin();it!=this->_indian.end();it++){
        (*it).show(painter);
    }
    this->_mole.show(painter);
    this->_ghost.show(painter);
    painter->setPen(QPen(Qt::white,4));
    painter->setBrush(QBrush(Qt::white));
    painter->drawRect(2.25*ICON::GRID_SIZE,6.2*ICON::GRID_SIZE,3.55*ICON::GRID_SIZE,0.3*ICON::GRID_SIZE);
    painter->drawRect(24.25*ICON::GRID_SIZE,6.2*ICON::GRID_SIZE,3.55*ICON::GRID_SIZE,0.3*ICON::GRID_SIZE);
    this->_moleblood.show(painter);
    this->_ghostblood.show(painter);
}

bool World::handleFireMove(){
    if(_fire.empty())
    {
        cout<<"Fire is empty!"<<endl;
        return moledead;
    }
    //移动fire
    vector<Weapon>::iterator it;
    for(it=_fire.begin();it!=_fire.end();it++)
    {
        it->move(3,2);
    }

    //判断fire是否与mole相遇
    it=_fire.begin();
    if(it->getPosX()<=_mole.getPosX()+4.5)
        {
            int preblood=_moleblood.getblood();
            _moleblood.setblood(it->getmin());
            if(_moleblood.getblood()/100!=preblood/100&&preblood!=1000)
            {
                QMediaPlayer * player = new QMediaPlayer;
                player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\hblood1.mp3"));
                player->setVolume(30);
                player->play();
            }
            _fire.erase(it);
            if(_moleblood.getblood()<=0)
            {
                moledead=true;
            }
            else
            {
                _mole.setpower(_moleblood.getblood()/100);
            }
            return moledead;
        }
    //判断fire是否与water相遇
    if(_water.empty())
    {
        return moledead;
    }
    it=_fire.begin();
    vector<Weapon>::iterator water;
    water=_water.begin();
    if (it->getPosX()<=water->getPosX())
    {
        int nf=it->getmin();
        int nw=water->getmin();
        cout<<nf<<" "<<nw<<endl;
        if(nf>nw)
        {
            _water.erase(water);
            it->setmin(nw);
        }
        else if(nf==nw)
        {
            _water.erase(water);
            _fire.erase(it);
        }
        else
        {
            _fire.erase(it);
            water->setmin(nf);
        }
    }
}

void World::ghost2fire()
{
    Weapon fire;
    fire=_ghost.usefire();
    fire.setPosX(22);
    fire.setPosY(9);
    this->_fire.push_back(fire);
}

bool World::handleWaterMove()
{
    if(_water.empty())
    {
        cout<<"Water is empty!"<<endl;
        return ghostdead;
    }
    vector<Weapon>::iterator it;
    for(it=_water.begin();it!=_water.end();it++)
    {
        it->move(4,5);
    }
    //判断mole是否与ghost相遇
    it=_water.begin();
    if(it->getPosX()+5>=_ghost.getPosX())
    {
        int preblood=_ghostblood.getblood();
        _ghostblood.setblood(it->getmin());
        if(_ghostblood.getblood()/100!=preblood/100&&preblood!=1000)
        {
            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\hblood1.mp3"));
            player->setVolume(30);
            player->play();
        }
        _water.erase(it);
        if(_ghostblood.getblood()<=0)
        {
            ghostdead=true;
        }
        else
        {
            _ghost.setpower(2*_ghostblood.getblood()/100);
        }
        return ghostdead;
    }
}

bool World::handleIndianMove()
{
    if(_indian.empty())
    {
        cout<<"Indian is empty!"<<endl;
        return ghostdead;
    }
    vector<Weapon>::iterator it;
    for(it=_indian.begin();it!=_indian.end();it++)
    {
        it->move(4,3);
    }
    it=_indian.begin();
    if(it->getPosX()>=_ghost.getPosX())
    {
        int preblood=_ghostblood.getblood();
        _ghostblood.setblood(it->getmin());
        if(_ghostblood.getblood()/100!=preblood/100&&preblood!=1000)
        {
            QMediaPlayer * player = new QMediaPlayer;
            player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\hblood1.mp3"));
            player->setVolume(30);
            player->play();
        }
        _indian.erase(it);
        if(_ghostblood.getblood()<=0)
        {
            ghostdead=true;
        }
        else
        {
            _ghost.setpower(2*_ghostblood.getblood()/100);
        }
        return ghostdead;
    }
}

void World::mole2water()
{
    Weapon water;
    water=_mole.usewater();
    water.setPosX(4);
    water.setPosY(9);
    this->_water.push_back(water);
}

void World::mole2indian()
{
    Weapon indian;
    indian=_mole.useindian();
    indian.setPosX(4);
    indian.setPosY(12);
    this->_indian.push_back(indian);
}
