#include "soldier.h"

Soldier::Soldier()
{

}

Soldier::~Soldier()
{

}

void Soldier::initpower(int n)
{
    power=n;
}

void Soldier::setpower(int n)
{
    power=n;
}
