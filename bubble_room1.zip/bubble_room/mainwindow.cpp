#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTime>
#include <QTimer>
#include "icon_br.h"
#include <map>
#include <iostream>

int MainWindow::count_scs = 0;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    _game.initWorld("N:\\material1.png");//TODO 应该是输入有效的地图文件

    //小猪的运动timer
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(pig1Move()));
    timer1->start(1000);
    timer1->setInterval(500);

    //以下是对player时钟的初始化
    timer0 = new QTimer(this);
   // timer0->setSingleShot(false);
    connect(timer0,SIGNAL(timeout()),this,SLOT(countTime()));
    timer0->start(100);
    timer0->setInterval(1000);

    //qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));


}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){   
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    pa->end();
    delete pa;
}

void MainWindow::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
        dir = 3;
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
        dir = 4;
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
        dir = 1;
    }
    else if(e->key() == Qt::Key_S)
    {
       this->_game.handlePlayerMove(2,1);
        dir = 2;
    }
    else if(e->key() == Qt::Key_K){//炸弹
        this->_game.placeBomb(_game.getPlayer());
    }

    //this->repaint();
    this->update();
}

/*void MainWindow::randomMove(){
    int d = 1 + rand()%4;
    //if(_game.getghostposX()>=0 && _game.getghostposX() <= 40 && _game.getghostposY() <=40 && _game.getghostposY() >= 3)
         this->_game.handleGhostMove(d,1);
    this->repaint();
}*/

void MainWindow::straightMove(){
   int d = dir;//游戏的初始情况是向右移动
   this->_game.handlePlayerMove(d,1);
   this->update();
}


void MainWindow::pig1Move(){
    if(_game._getPig1().getplayerHasSet() == 1) return;
//在这里加一段判断自己身边的位置是否是空的代码
    bool te = 1, be = 1, le = 1, re = 1;
    vector<int> last_steps;
    int ls = 0;
    for(int i = 0; i < _game.getVectorSize(); i++){
        if((_game.getPig1().getPosX() + 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY()+1 == _game.getObjects(i).getPosY()) || _game.getPig1().getPosX()+1 == 26){
            re = 0;
        }
        if((_game.getPig1().getPosX() - 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY() + 1 == _game.getObjects(i).getPosY() )|| _game.getPig1().getPosX()-1 == -1){
            le = 0;
        }
        if((_game.getPig1().getPosY()  == _game.getObjects(i).getPosY()&&_game.getPig1().getPosX() == _game.getObjects(i).getPosX() ) || _game.getPig1().getPosY()-1 == -2){
            te = 0;
        }
        if((_game.getPig1().getPosY() + 2 == _game.getObjects(i).getPosY() && _game.getPig1().getPosX() == _game.getObjects(i).getPosX()) || _game.getPig1().getPosY()+2 == 18){
            be = 0;
        }
    }
//----------先判断上下位置-----------------
    int rd = 0;
    if(_game.getPlayer().getPosY()<_game.getPig1().getPosY() && te == 1){
        dir1 = 1;
        ls = dir1;
        last_steps.push_back(ls);
    }
    else if(_game.getPlayer().getPosY()>_game.getPig1().getPosY() && be == 1){
        dir1 = 2;
        ls = dir1;
        last_steps.push_back(ls);
    }
    else{
         dir1 = 5;
         rd ++;
    }
    int d = dir1;
    this->_game.handlePigMove(d, 1, _game.getPig1());
    this->update();

//---------------再判断左右位置-----------------//拐弯处再作修改
    if(_game.getPlayer().getPosX()<_game.getPig1().getPosX() && le == 1){
        dir1 = 3;
        ls = dir1;
        last_steps.push_back(ls);
      }
    else if(_game.getPlayer().getPosX()>_game.getPig1().getPosX() && re == 1){
        dir1 = 4;
        ls = dir1;
        last_steps.push_back(ls);
    }
    else{
        dir1 = 5;
        rd++;
    }
    d = dir1;
    this->_game.handlePigMove(d, 1, _game.getPig1());
    this->update();
 //-------------放置炸弹并逃跑--------------------
    if(rd == 2){
        _game.placeBomb(_game.getPig1());
        _game.getPig1().changeHasSet();
 //---------------------逃跑(不用逃了，自己炸不自自己即可。。)----------------------
     //逃跑第一步
       /* int e1, e2;
        if(last_steps[last_steps.size() - 1] == 1) e1 = 2;
        if(last_steps[last_steps.size() - 1] == 2) e1 = 1;
        if(last_steps[last_steps.size() - 1] == 3) e1 = 4;
        if(last_steps[last_steps.size() - 1] == 4) e1 = 3;
        this->_game.handlePigMove(e1, 1, _game.getPig1());

        if(last_steps[last_steps.size() - 2] == 1) e2 = 2;
        if(last_steps[last_steps.size() - 2] == 2) e2 = 1;
        if(last_steps[last_steps.size() - 2] == 3) e2 = 4;
        if(last_steps[last_steps.size() - 2] == 4) e2 = 3;
        this->_game.handlePigMove(e2, 1, _game.getPig1());

        /*for(int i = 0; i < _game.getVectorSize(); i++){
            if((_game.getPig1().getPosX() + 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY()+1 == _game.getObjects(i).getPosY()) || _game.getPig1().getPosX()+1 == 26){
                re = 0;
                this->_game.handlePigMove(4, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosX() - 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY() + 1 == _game.getObjects(i).getPosY() )|| _game.getPig1().getPosX()-1 == -1){
                le = 0;
                this->_game.handlePigMove(3, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosY()  == _game.getObjects(i).getPosY()&&_game.getPig1().getPosX() == _game.getObjects(i).getPosX() ) || _game.getPig1().getPosY()-1 == -2){
                te = 0;
                this->_game.handlePigMove(1, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosY() + 2 == _game.getObjects(i).getPosY() && _game.getPig1().getPosX() == _game.getObjects(i).getPosX()) || _game.getPig1().getPosY()+2 == 18){
                be = 0;
                this->_game.handlePigMove(2, 1, _game.getPig1());
            }
        }
        //逃跑第二步
        for(int i = 0; i < _game.getVectorSize(); i++){
            if((_game.getPig1().getPosX() + 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY()+1 == _game.getObjects(i).getPosY()) || _game.getPig1().getPosX()+1 == 26){
                re = 0;
                this->_game.handlePigMove(4, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosX() - 1 == _game.getObjects(i).getPosX() && _game.getPig1().getPosY() + 1 == _game.getObjects(i).getPosY() )|| _game.getPig1().getPosX()-1 == -1){
                le = 0;
                this->_game.handlePigMove(3, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosY()  == _game.getObjects(i).getPosY()&&_game.getPig1().getPosX() == _game.getObjects(i).getPosX() ) || _game.getPig1().getPosY()-1 == -2){
                te = 0;
                this->_game.handlePigMove(1, 1, _game.getPig1());
            }
            else if((_game.getPig1().getPosY() + 2 == _game.getObjects(i).getPosY() && _game.getPig1().getPosX() == _game.getObjects(i).getPosX()) || _game.getPig1().getPosY()+2 == 18){
                be = 0;
                this->_game.handlePigMove(2, 1, _game.getPig1());
            }

        }*/

    }

}


void MainWindow::countTime(){
    count_scs++;
    this->update();
    }
