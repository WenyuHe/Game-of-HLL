#include "player_br.h"
#include "rpgobj_br.h"
#include"world_br.h"
#include"mainwindow.h"

//direction =1,2,3,4 for 上下左右
void Player_br::move(int direction, int steps){

    switch (direction){
        case 1:
            this->_pos_y -= steps;
            break;
        case 2:
            this->_pos_y += steps;
            break;
        case 3:
            this->_pos_x -= steps;
            break;
        case 4:
            this->_pos_x += steps;
            break;
        case 5:
            this->_pos_x = this->_pos_x;
            this->_pos_y = this->_pos_y;
            break;
    }
}

int Player_br::count0 = 0;
int Player_br::count1 = 0;
int Player_br::count2 = 0;
int Player_br::count3 = 0;


