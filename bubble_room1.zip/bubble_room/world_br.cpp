//为什么走到原放炸弹处就会被炸死？

//自己的炸弹是否可以炸死

#include "world_br.h"
#include"iostream"
#include "icon_br.h"
#include"rpgobj_br.h"
#include"object_br.h"
#include <QTimer>
#include<QTime>
#include"mainwindow.h"
using namespace std;

bool World_br::has_eaten = false;

void World_br::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5
    this->_player.initObj("player");
    this->_player.setPosX(7);
    this->_player.setPosY(8);

    this->_pig1.initObj("pig1");
    this->_pig1.setPosX(4);
    this->_pig1.setPosY(10);

    this->_pig2.initObj("pig2");
    this->_pig2.setPosX(19);
    this->_pig2.setPosY(4);

    this->_pig3.initObj("pig3");
    this->_pig3.setPosX(21);
    this->_pig3.setPosY(14);

    RPGObj_br O_init;
    //----------四个角--------------
    O_init.placeObject_h("shelf", 6, 0, 0, &_objs);
    O_init.placeObject_h("frige", 6, 0, 1, &_objs);
    O_init.placeObject_h("shelf", 6, 0, 2, &_objs);
    O_init.placeObject_h("frige", 6, 0, 3, &_objs);
    O_init.placeObject_h("shelf", 6, 0, 4, &_objs);

    O_init.placeObject_v("frige", 5, 0, 13, &_objs);
    O_init.placeObject_v("chair", 5, 1, 13, &_objs);
    O_init.placeObject_v("frige", 5, 2, 13, &_objs);
    O_init.placeObject_v("desk", 5, 3, 13, &_objs);
    O_init.placeObject_v("frige",5, 4, 13, &_objs);

    O_init.placeObject_h("desk", 5, 22, 0, &_objs);
    O_init.placeObject_h("chair", 5, 22, 1, &_objs);
    O_init.placeObject_h("shelf", 5, 22, 2, &_objs);
    O_init.placeObject_h("sofa", 5, 22, 3, &_objs);
    O_init.placeObject_h("shelf", 5, 22, 4, &_objs);

    O_init.placeObject_v("shelf", 5, 22, 13, &_objs);
    O_init.placeObject_v("chair", 5, 23, 13, &_objs);
    O_init.placeObject_v("frige", 5, 24, 13, &_objs);
    O_init.placeObject_v("desk", 5, 25, 13, &_objs);
    O_init.placeObject_v("frige",5, 26, 13, &_objs);

    //------------------中间一大块----------------------

    O_init.placeObject_v("desk",2, 8, 3, &_objs);
    O_init.placeObject_v("frige",1, 8, 5, &_objs);
    O_init.placeObject_v("chair",4, 8, 6, &_objs);
    O_init.placeObject_v("frige",3, 8, 10, &_objs);
    O_init.placeObject_v("shelf",2, 8, 13, &_objs);

    O_init.placeObject_h("chair", 1, 9, 14, &_objs);
    O_init.placeObject_h("desk", 3, 10, 14, &_objs);
    O_init.placeObject_h("sofa", 2, 13, 14, &_objs);
    O_init.placeObject_h("shelf", 1, 15, 14, &_objs);
    O_init.placeObject_h("chair", 2, 16, 14, &_objs);

    O_init.placeObject_v("chair",1, 18, 3, &_objs);
    O_init.placeObject_v("sofa",2, 18, 4, &_objs);
    O_init.placeObject_v("chair",2, 18, 6, &_objs);
    O_init.placeObject_v("desk",2, 18, 8, &_objs);
    O_init.placeObject_v("frige",2, 18, 10, &_objs);
    O_init.placeObject_v("shelf",3, 18, 12, &_objs);

    O_init.placeObject_h("frige", 1, 9, 3, &_objs);
    O_init.placeObject_h("sofa", 3, 10, 3, &_objs);
    O_init.placeObject_h("desk", 2, 13, 3, &_objs);
    O_init.placeObject_h("shelf", 1, 15, 3, &_objs);
    O_init.placeObject_h("chair", 2, 16, 3, &_objs);

//----------8<x<18-------3<y<14--------------
    //----------中间框内第一列-------------------
    O_init.placeObject_v("frige",3, 9, 4, &_objs);
    O_init.placeObject_v("chair",1, 9, 7, &_objs);
    O_init.placeObject_v("desk",2, 9, 8, &_objs);
    O_init.placeObject_v("sofa",1, 9, 11, &_objs);
    O_init.placeObject_v("desk",2, 9, 12, &_objs);
    //------------------中间框内第二列-------------------
    O_init.placeObject_v("sofa",1, 10, 5, &_objs);
    O_init.placeObject_v("frige",3, 10, 6, &_objs);
    O_init.placeObject_v("desk",2, 10, 10, &_objs);
    O_init.placeObject_v("shelf",1, 10, 12, &_objs);
    O_init.placeObject_v("chair",1, 10, 13, &_objs);
    //---------中间框内第三列----------------------
    O_init.placeObject_v("frige",1, 11, 5, &_objs);
    O_init.placeObject_v("desk", 3, 11, 8, &_objs);
    O_init.placeObject_v("chair",2, 11, 12, &_objs);
    //--------中间框内第四列---------------------
    O_init.placeObject_v("sofa",3, 12, 5, &_objs);
    O_init.placeObject_v("frige",2, 12, 8, &_objs);
    O_init.placeObject_v("chair",2, 12, 10, &_objs);
    //--------中间框内第四列--------------
    O_init.placeObject_v("desk",1, 13, 5, &_objs);
    O_init.placeObject_v("chair",2, 13, 6, &_objs);
    O_init.placeObject_v("desk",1, 13, 8, &_objs);
    O_init.placeObject_v("frige",3, 13, 11, &_objs);
    //---------中间框内第五列---------------
    O_init.placeObject_v("sofa",2, 14, 4, &_objs);
    O_init.placeObject_v("desk",1, 14, 7, &_objs);
    O_init.placeObject_v("frige",3, 14, 9, &_objs);
    O_init.placeObject_v("chair",2, 14, 12, &_objs);
    //---------中间框内第六列-------------------
    O_init.placeObject_v("desk",2, 15, 4, &_objs);
    O_init.placeObject_v("frige",1, 15, 8, &_objs);
    O_init.placeObject_v("chair",3, 15, 9, &_objs);
    O_init.placeObject_v("sofa",1, 15, 12, &_objs);
    O_init.placeObject_v("frige",1, 15, 13, &_objs);
    //-------------中间框内第七列-----------------------
    O_init.placeObject_v("frige", 3, 16, 4, &_objs);
    O_init.placeObject_v("sofa", 1, 16, 9, &_objs);
    O_init.placeObject_v("frige",2, 16, 10, &_objs);
    O_init.placeObject_v("desk",2, 16, 12, &_objs);
    //------------中间框内第八列-----------------------
    O_init.placeObject_v("chair",1, 17, 4, &_objs);
    O_init.placeObject_v("shelf",4, 17, 6, &_objs);
    O_init.placeObject_v("desk",2, 17, 10, &_objs);
    O_init.placeObject_v("frige",1, 17, 12, &_objs);
    O_init.placeObject_v("chair",1, 17, 13, &_objs);

    //------------------其他小块（左区）---------------------
    //-----------------line1----------------------------
    O_init.placeObject_h("sofa", 3, 0, 5, &_objs);
    O_init.placeObject_h("chair", 3, 5, 5, &_objs);
    //-----------------line2----------------------
    O_init.placeObject_h("frige", 1, 1, 6, &_objs);
    O_init.placeObject_h("shelf", 2, 3, 6, &_objs);
    O_init.placeObject_h("desk", 2, 6, 6, &_objs);
    //-----------------line3------------------------------
    O_init.placeObject_h("chair", 4, 1, 7, &_objs);
    O_init.placeObject_h("frige", 2, 6, 7, &_objs);
    //-------------------line4---------------------------
    O_init.placeObject_h("chair", 1, 0, 8, &_objs);
    O_init.placeObject_h("sofa", 1, 1, 8, &_objs);
    O_init.placeObject_h("desk", 3, 2, 8, &_objs);
    O_init.placeObject_h("frige", 2, 5, 8, &_objs);
    //----------------------line5----------------------
    O_init.placeObject_h("desk", 5, 0, 9, &_objs);
    //----------------------line6-------------------------
    O_init.placeObject_h("frige", 3, 2, 10, &_objs);
    O_init.placeObject_h("desk", 2, 5, 10, &_objs);
    O_init.placeObject_h("frige", 1, 7, 10, &_objs);
    //-------------------line7--------------------------
    O_init.placeObject_h("frige", 3, 0, 11, &_objs);
    O_init.placeObject_h("shelf", 1, 5, 11, &_objs);
    //----------------------line8------------------
    O_init.placeObject_h("desk", 1, 4, 12, &_objs);
    O_init.placeObject_h("chair", 3, 5, 12, &_objs);


//--------------------其他小块（右区）--------------------
    //-----------------line1----------------------------
    O_init.placeObject_h("desk", 3, 20, 5, &_objs);
    O_init.placeObject_h("chair", 3, 24, 5, &_objs);
    //-----------------line2----------------------
    O_init.placeObject_h("frige", 1, 19, 6, &_objs);
    O_init.placeObject_h("shelf", 2, 22, 6, &_objs);
    O_init.placeObject_h("desk", 2, 25, 6, &_objs);
    //-----------------line3------------------------------
    O_init.placeObject_h("chair", 4, 20, 7, &_objs);
    O_init.placeObject_h("frige", 2, 24, 7, &_objs);
    //-------------------line4---------------------------
    O_init.placeObject_h("chair", 1, 19, 8, &_objs);
    O_init.placeObject_h("sofa", 1, 21, 8, &_objs);
    O_init.placeObject_h("desk", 3, 22, 8, &_objs);
    O_init.placeObject_h("frige", 2, 25, 8, &_objs);
    //----------------------line5----------------------
    O_init.placeObject_h("desk", 5, 21, 9, &_objs);
    //----------------------line6-------------------------
    O_init.placeObject_h("frige", 3, 21, 10, &_objs);
    O_init.placeObject_h("desk", 2, 24, 10, &_objs);
    O_init.placeObject_h("frige", 1, 26, 10, &_objs);
    //-------------------line7--------------------------
    O_init.placeObject_h("frige", 3, 22, 11, &_objs);
    O_init.placeObject_h("shelf", 1, 26, 11, &_objs);
    //----------------------line8------------------
    O_init.placeObject_h("desk", 1, 24, 12, &_objs);

//--------------其他小块（上区）-----------------------
    //-------line1------------------------------
    O_init.placeObject_h("desk", 3, 7, 0, &_objs);
    O_init.placeObject_h("chair", 2, 13, 0, &_objs);
    O_init.placeObject_h("shelf", 1, 17, 0, &_objs);
    O_init.placeObject_h("desk", 2, 20, 0, &_objs);
    //-------line2------------------
    O_init.placeObject_h("chair", 5, 6, 1, &_objs);
    O_init.placeObject_h("desk", 3, 14, 1, &_objs);
    O_init.placeObject_h("sofa", 4, 18, 1, &_objs);
    //-----------line3-------------------
    O_init.placeObject_h("chair", 3, 15, 2, &_objs);
//--------------其他小块（下区）-------------------------
    //-------line3------------------------------
    O_init.placeObject_h("desk", 4, 12, 15, &_objs);
    //-------line2------------------
    O_init.placeObject_h("chair", 3, 8, 16, &_objs);
    O_init.placeObject_h("desk", 3, 14, 16, &_objs);
    O_init.placeObject_h("sofa", 4, 18, 16, &_objs);
    //-----------line1-------------------
    O_init.placeObject_h("chair", 3, 7, 17, &_objs);
    O_init.placeObject_h("sofa", 2, 13, 17, &_objs);
    O_init.placeObject_h("shelf", 1, 17, 17, &_objs);
    O_init.placeObject_h("desk", 2, 20, 17, &_objs);

}

bool World_br::beBombed(Player_br p){
    bool is_bombed = 0;
    for(int i = 0; i < 4; i++){
        if((p.getPosX()>=bomb[i].getPosX()-1 && p.getPosX() <= bomb[i].getPosX()+1 && p.getPosY() + 1 == bomb[i].getPosY())
               || (p.getPosY() >= bomb[i].getPosY() - 1 && p.getPosY() <= bomb[i]. getPosY()+1 && p.getPosX() == bomb[i].getPosX())){
            if((p.getObjType() == "pig1" || p.getObjType() == "pig2" || p.getObjType() == "pig3")&& i > 0)
                is_bombed = 0;

             else is_bombed = 1;
         }

    }
    return is_bombed;
}

//解决炸弹重置问题，不然就算已经爆炸完毕走到原地依旧会死
void World_br::show(QPainter * painter){
    if(dead == 1) return;//游戏结束
    if(dead == 0 && dead1 == 1 && dead2 == 1 && dead3 == 1) return;//游戏胜利
    //------player的炸弹---------------
    if(MainWindow::count_scs - placeTime[0] <= 2 ){
        this->bomb[0].show(painter);
    }
    if(MainWindow::count_scs - placeTime[0] >2 && MainWindow::count_scs - placeTime[0] <= 4){
        for(int i = 0; i < _objs.size(); i++){
            if((_objs[i].getPosX()>=bomb[0].getPosX()-1 && _objs[i].getPosX() <= bomb[0].getPosX()+1 && _objs[i].getPosY() == bomb[0].getPosY())
                    || (_objs[i].getPosY() >= bomb[0].getPosY() - 1 && _objs[i].getPosY() <= bomb[0]. getPosY()+1 && _objs[i].getPosX() == bomb[0].getPosX())){
                if(_objs[i].canBomb() == 1){
                    _objs.erase(_objs.begin()+i);
                }
            }
        }
        this->blast_h[0].show(painter);
        this->blast_v[0].show(painter);
        have_exploded[0] = 1;
        _player.resetHasSet();
        if(beBombed(_player) == 1){
            //游戏结束
            dead = 1;
        }
        if(beBombed(_pig1) == 1){
            //游戏结束
            dead1 = 1;
        }
        if(beBombed(_pig2) == 1){
            //游戏结束
            dead2 = 1;
        }
        if(beBombed(_pig3) == 1){
            //游戏结束
            dead3 = 1;
        }

    }


    //---------pig1的炸弹------------------
    if(MainWindow::count_scs - placeTime[1] <= 2 ){
        this->bomb[1].show(painter);
    }
    if(MainWindow::count_scs - placeTime[1] >2 && MainWindow::count_scs - placeTime[1] <= 4){
        for(int i = 0; i < _objs.size(); i++){
            if(_objs[i].getPosX()>=bomb[1].getPosX()-1 && _objs[i].getPosX() <= bomb[1].getPosX()+1 && _objs[i].getPosY() == bomb[1].getPosY()
                    || _objs[i].getPosY() >= bomb[1].getPosY() - 1 && _objs[i].getPosY() <= bomb[1]. getPosY()+1 && _objs[i].getPosX() == bomb[1].getPosX()){
                if(_objs[i].canBomb() == 1){
                    _objs.erase(_objs.begin()+i);
                }
            }
        }
        this->blast_h[1].show(painter);
        this->blast_v[1].show(painter);
        have_exploded[1] = 1;
        _pig1.resetHasSet();
        if(beBombed(_player) == 1){
            //游戏结束
            dead = 1;
        }
        if(beBombed(_pig1) == 1){
            //游戏结束
            dead1 = 1;
        }
        if(beBombed(_pig2) == 1){
            //游戏结束
            dead2 = 1;
        }
        if(beBombed(_pig3) == 1){
            //游戏结束
            dead3 = 1;
        }

    }


  //---------pig2的炸弹--------------
        if(MainWindow::count_scs - placeTime[2] <= 2 ){
            this->bomb[1].show(painter);
        }
        if(MainWindow::count_scs - placeTime[2] >2 && MainWindow::count_scs - placeTime[2] <= 4){
            for(int i = 0; i < _objs.size(); i++){
                if(_objs[i].getPosX()>=bomb[2].getPosX()-1 && _objs[i].getPosX() <= bomb[2].getPosX()+1 && _objs[i].getPosY() == bomb[2].getPosY()
                        || _objs[i].getPosY() >= bomb[2].getPosY() - 1 && _objs[i].getPosY() <= bomb[2]. getPosY()+1 && _objs[i].getPosX() == bomb[2].getPosX()){
                    if(_objs[i].canBomb() == 1){
                        _objs.erase(_objs.begin()+i);
                    }
                }
            }
            this->blast_h[2].show(painter);
            this->blast_v[2].show(painter);
            have_exploded[2] = 1;
        if(beBombed(_player) == 1){
                //游戏结束
                dead = 1;
            }
            if(beBombed(_pig1) == 1){
                //游戏结束
                dead1 = 1;
            }
            if(beBombed(_pig2) == 1){
                //游戏结束
                dead2 = 1;
            }
            if(beBombed(_pig3) == 1){
                //游戏结束
                dead3 = 1;
            }

        }


 //----------------pig3的炸弹-------------------
            if(MainWindow::count_scs - placeTime[3] <= 2 ){
                this->bomb[3].show(painter);
            }
            if(MainWindow::count_scs - placeTime[3] >2 && MainWindow::count_scs - placeTime[3] <= 4){
                for(int i = 0; i < _objs.size(); i++){
                    if(_objs[i].getPosX()>=bomb[3].getPosX()-1 && _objs[i].getPosX() <= bomb[3].getPosX()+1 && _objs[i].getPosY() == bomb[3].getPosY()
                            || _objs[i].getPosY() >= bomb[3].getPosY() - 1 && _objs[i].getPosY() <= bomb[3]. getPosY()+1 && _objs[i].getPosX() == bomb[3].getPosX()){
                        if(_objs[i].canBomb() == 1){
                            _objs.erase(_objs.begin()+i);
                        }
                    }
                }
                this->blast_h[3].show(painter);
                this->blast_v[3].show(painter);
                have_exploded[3] = 1;
                if(beBombed(_player) == 1){
                    //游戏结束
                    dead = 1;
                }
                if(beBombed(_pig1) == 1){
                    //游戏结束
                    dead1 = 1;
                }
                if(beBombed(_pig2) == 1){
                    //游戏结束
                    dead2 = 1;
                }
                if(beBombed(_pig3) == 1){
                    //游戏结束
                    dead3 = 1;
                }

}


           /* for(int i = 0; i < 4; i++){
                if(have_exploded[i] == 1)
                    bomb[i].setPosX(-1);
                    bomb[i].setPosY(-1);
            }*/
    //vector<RPGObj_br>::iterator it;
    for(int i = 0; i < _objs.size(); i++){
            _objs[i].show(painter);
    }
    if(dead1 == 0)
        this->_pig1.show(painter);
    if(dead2 == 0)
        this->_pig2.show(painter);
    if(dead3 == 0)
        this->_pig3.show(painter);
    this->_player.show(painter);

    }


void World_br::paintEvent(QPaintEvent* )
{
    if(dead == 1){
     QPainter painter;
     QPixmap pix;
     pix.load("N:\\TileB.png");
     painter.drawPixmap(0,0,100,33,pix);
     //painter.drawLine(0,0,100,100);
     return;
    }
    else return;
}

/*void World_br::showBomb(QPainter *p){*/


void World_br::handlePlayerMove(int direction, int steps){
    switch (direction){
        case 1://up
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == -1){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 - 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }
        }

           this->_player.move(direction, steps);
            break;

        case 2://down
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == 16){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 + 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
        this->_player.move(direction, steps);
            break;
        case 3://left
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 0){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1 == _objs[i].getPosY() && this->_player.getPosX() - 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
           this->_player.move(direction, steps);
            break;
        case 4://right
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 26){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1== _objs[i].getPosY() && this->_player.getPosX() + 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }

            }

        }
            this->_player.move(direction, steps);
            break;
        case 5:
            this->_player.move(direction, steps);
            break;
   // this->_player.move(direction, steps);
   }
}

void World_br::handlePigMove(int direction, int steps, Player_br &pig){
    switch (direction){
        case 1://up
        for(int i = 0; i < _objs.size(); i++){
            if(pig.getPosY() == -1){
                pig.move(5, steps);
                return;
            }
            if((pig.getPosY()+ 1 - 1 == _objs[i].getPosY() && pig.getPosX() == _objs[i].getPosX())||(pig.getPosY()+ 1 - 1 == bomb[0].getPosY() && pig.getPosX() == bomb[0].getPosX())){
                pig.top_empty = 0;
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    pig.move(5, steps);
                    has_stoped++;
                    return;
                }
            }
        }
           pig.move(direction, steps);
           break;

        case 2://down
        for(int i = 0; i < _objs.size(); i++){
            if(pig.getPosY() == 16){
                pig.move(5, steps);
                return;
            }
            if((pig.getPosY()+ 1 + 1 == _objs[i].getPosY() && pig.getPosX() == _objs[i].getPosX())||(pig.getPosY()+ 1 + 1 == bomb[0].getPosY() && pig.getPosX() == bomb[0].getPosX())){
                pig.bottom_empty = 0;
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    pig.move(5, steps);
                    has_stoped++;
                    return;
                }

            }

        }
       pig.move(direction, steps);
            break;
        case 3://left
        for(int i = 0; i < _objs.size(); i++){
            if(pig.getPosX() == 0){
                pig.move(5, steps);
                return;
            }
            if((pig.getPosY() + 1 == _objs[i].getPosY() &&pig.getPosX() - 1 == _objs[i].getPosX())||(pig.getPosY() + 1 == bomb[0].getPosY() &&pig.getPosX() - 1 == bomb[0].getPosX())){
                pig.left_empty = 0;
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    pig.move(5, steps);
                    has_stoped++;
                    return;
                }

            }

        }
           pig.move(direction, steps);
            break;
        case 4://right
        for(int i = 0; i < _objs.size(); i++){
            if(pig.getPosX() == 26){
                pig.move(5, steps);
                return;
            }
            if((pig.getPosY() + 1== _objs[i].getPosY() && pig.getPosX() + 1 == _objs[i].getPosX())||(pig.getPosY() + 1== bomb[0].getPosY() && pig.getPosX() + 1 == bomb[0].getPosX())){
                pig.right_empty = 0;
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    pig.move(5, steps);
                    has_stoped++;
                    return;
                }

            }

        }
            pig.move(direction, steps);
            break;
        case 5:
            pig.move(direction, steps);
            break;
   }
    stopped = has_stoped;
}

int World_br::getobjX(int i){
    return _objs[i].getPosX();
}

int World_br::getobjY(int i){
    return _objs[i].getPosY();
}

bool World_br::getCanCover(int i){
    return _objs[i].canCover();
}

bool World_br::getCanEat(int i){
    return _objs[i].canEat();
}

void World_br::placeBomb(Player_br p){
    if(p.getObjType() == "player"){
        placeTime[0] = MainWindow::count_scs;
        this->_player.changeHasSet();
        bomb[0].initObj("bomb");
        bomb[0].setPosX(p.getPosX());
        bomb[0].setPosY(p.getPosY()+1);
        blast_h[0].initObj("blast_h");
        blast_h[0].setPosX(p.getPosX() - 1);
        blast_h[0].setPosY(p.getPosY() + 1);
        blast_v[0].initObj("blast_v");
        blast_v[0].setPosX(p.getPosX());
        blast_v[0].setPosY(p.getPosY());
    }

    if(p.getObjType() == "pig1"){
        placeTime[1] = MainWindow::count_scs;
        this->_pig1.changeHasSet();
        bomb[1].initObj("bomb");
        bomb[1].setPosX(p.getPosX());
        bomb[1].setPosY(p.getPosY()+1);
        blast_h[1].initObj("blast_h");
        blast_h[1].setPosX(p.getPosX() - 1);
        blast_h[1].setPosY(p.getPosY()+1);
        blast_v[1].initObj("blast_v");
        blast_v[1].setPosX(p.getPosX());
        blast_v[1].setPosY(p.getPosY() );
    }

    if(p.getObjType() == "pig2"){
        placeTime[2] = MainWindow::count_scs;
        this->_pig2.changeHasSet();
        bomb[2].initObj("bomb");
        bomb[2].setPosX(p.getPosX());
        bomb[2].setPosY(p.getPosY()+1);
        blast_h[2].initObj("blast_h");
        blast_h[2].setPosX(p.getPosX() - 1);
        blast_h[2].setPosY(p.getPosY()+1);
        blast_v[2].initObj("blast_v");
        blast_v[2].setPosX(p.getPosX());
        blast_v[2].setPosY(p.getPosY() );
    }

    if(p.getObjType() == "pig3"){
        placeTime[3] = MainWindow::count_scs;
        this->_pig3.changeHasSet();
        bomb[3].initObj("bomb");
        bomb[3].setPosX(p.getPosX());
        bomb[3].setPosY(p.getPosY()+1);
        blast_h[3].initObj("blast_h");
        blast_h[3].setPosX(p.getPosX() - 1);
        blast_h[3].setPosY(p.getPosY()+1);
        blast_v[3].initObj("blast_v");
        blast_v[3].setPosX(p.getPosX());
        blast_v[3].setPosY(p.getPosY() );
    }
}

/*void World_br::controlExplode0(){
        if( _player.count0 <=2) this->_player.ctrl_expld0();
        if(_player.count0 == 3){
            _player.resetHasSet();
        }
        if(_player.count0 == 5) {
            _player.reset_count0();
        }
    }


void World_br::controlExplode1(){
    this->_pig1.ctrl_expld1();
}

void World_br::controlExplode2(){
    this->_pig2.ctrl_expld2();
}

void World_br::controlExplode3(){
    this->_pig3.ctrl_expld3();
}
*/
