#ifndef WORLD_BR_H
#define WORLD_BR_H
#include "rpgobj_br.h"
#include <vector>
#include <string>
#include <QPainter>
#include<QLabel>
#include "player_br.h"
#include"object_br.h"
#include<QTimer>

class World_br
{
public:
    World_br(){}
    ~World_br(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void show(QPainter * painter);
    void paintEvent(QPaintEvent* );
    //void showBomb(QPainter *p);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    void handlePigMove(int direction, int steps, Player_br &pig);
    void pigMove();
    int getobjX(int i);
    int getobjY(int i);
    bool getCanCover(int i);
    bool getCanBomb(int i);
    bool getCanEat(int i);
    void placeBomb(Player_br p);
    Player_br getPlayer(){return this->_player;}
    Player_br &getPig1(){return this->_pig1;}
    Player_br &getPig2(){return this->_pig2;}
    Player_br &getPig3(){return this->_pig3;}
    Player_br _getPig1(){return this->_pig1;}
    Player_br _getPig2(){return this->_pig2;}
    Player_br _getPig3(){return this->_pig3;}
    void resetHasStoped(){ this->has_stoped = 0;}
    int getStopped(){return this->stopped;}
    bool getHaveExplded(int i){return this->have_exploded[i];}
    int getVectorSize(){return _objs.size();}
    RPGObj_br getObjects(int i){return _objs[i];}
   /* void controlExplode0();
    void controlExplode1();
    void controlExplode2();
    void controlExplode3();*/
    bool beBombed(Player_br p);
    bool isDead(){return this-> dead;}
    static bool has_eaten;
    //int get_has_eaten() const;
    //int getghostposX();
    //int getghostposY();

    //假定只有一个玩家
private:
   vector<RPGObj_br>_objs;
    Player_br _player;
    Player_br _pig1;
    Player_br _pig2;
    Player_br _pig3;
    Object_br bomb[4];
    Object_br blast_h[4];
    Object_br blast_v[4];
    bool dead = 0, dead1 = 0, dead2 = 0, dead3 = 0;
    QTimer timer0;
    int placeTime[4] = {-100, -100, -100, -100};
    int has_stoped = 0, stopped = 0;
    bool have_exploded[4] = {0};

};

#endif // WORLD_BR_H
