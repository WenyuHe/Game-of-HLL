#ifndef PLAYER_BR_H
#define PLAYER_BR_H
#include "rpgobj_br.h"
class Player_br: public RPGObj_br
{
public:
    Player_br():_has_set_boom(0){}
    ~Player_br(){}
    void move(int direction, int steps=1);
    void changeHasSet(){_has_set_boom = 1;}
    void resetHasSet(){_has_set_boom = 0;}
    bool getplayerHasSet(){return this->_has_set_boom;}
        //direction =1,2,3,4 for 上下左右
    static int count0;
    static int count1;
    static int count2;
    static int count3;
    void ctrl_expld0(){count0 ++;}
    void ctrl_expld1(){count1 ++;}
    void ctrl_expld2(){count2 ++;}
    void ctrl_expld3(){count3 ++;}
    void reset_count0(){count0 = 0;}
    void reset_count1(){count1 = 0;}
    void reset_count2(){count2 = 0;}
    void reset_count3(){count3 = 0;}
    bool left_empty = 1, right_empty = 1, top_empty = 1, bottom_empty = 1;
private:
       bool _has_set_boom;

};


#endif // PLAYER_BR_H
