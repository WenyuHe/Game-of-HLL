#include "world_br.h"
#include"iostream"
#include "icon_br.h"
#include"rpgobj_br.h"
#include"object_br.h"
#include <QTimer>
#include<QTime>
#include"mainwindow.h"
#include<QPainter>
#include <QMediaPlayer>


using namespace std;

bool World_br::has_eaten = false;

//改---------------------
void World_br::placeObject_v(string obj, int length, int posX, int posY){
    if (obj.compare("sofa")==0||obj.compare("chair")==0||obj.compare("frige")==0||obj.compare("desk")==0||obj.compare("shelf")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj(obj);
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            _objs.push_back(_obj);
            posY++;
        }
    }
}

void World_br::placeObject_h(string obj, int length, int posX, int posY){
        if (obj.compare("sofa")==0||obj.compare("chair")==0||obj.compare("frige")==0||obj.compare("desk")==0||obj.compare("shelf")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj(obj);
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                _objs.push_back(_obj);
                posX++;

        }
    }
}


void World_br::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5

    this->_player.initObj("player");
    this->_player.setPosX(7);
    this->_player.setPosY(8);

    Player_br pig;
    pig.initObj("pig1");
    pig.setPosX(4);
    pig.setPosY(10);
    _pigs.push_back(pig);

    pig.initObj("pig2");
    pig.setPosX(11);
    pig.setPosY(1);
    _pigs.push_back(pig);

    pig.initObj("pig1");
    pig.setPosX(21);
    pig.setPosY(14);
    _pigs.push_back(pig);

    //----------四个角--------------
     placeObject_h("shelf", 6, 0, 0 );
     placeObject_h("frige", 6, 0, 1 );
     placeObject_h("shelf", 6, 0, 2 );
     placeObject_h("frige", 6, 0, 3 );
     placeObject_h("shelf", 6, 0, 4 );

     placeObject_v("frige", 5, 0, 13 );
     placeObject_v("chair", 5, 1, 13 );
     placeObject_v("frige", 5, 2, 13 );
     placeObject_v("desk", 5, 3, 13 );
     placeObject_v("frige",5, 4, 13 );

     placeObject_h("desk", 5, 22, 0 );
     placeObject_h("chair", 5, 22, 1 );
     placeObject_h("shelf", 5, 22, 2 );
     placeObject_h("sofa", 5, 22, 3 );
     placeObject_h("shelf", 5, 22, 4 );

     placeObject_v("shelf", 5, 22, 13 );
     placeObject_v("chair", 5, 23, 13 );
     placeObject_v("frige", 5, 24, 13 );
     placeObject_v("desk", 5, 25, 13 );
     placeObject_v("frige",5, 26, 13 );

    //------------------中间一大块----------------------

     placeObject_v("desk",2, 8, 3 );
     placeObject_v("frige",1, 8, 5 );
     placeObject_v("chair",4, 8, 6 );
     placeObject_v("frige",3, 8, 10 );
     placeObject_v("shelf",2, 8, 13 );

     placeObject_h("chair", 1, 9, 14 );
     placeObject_h("desk", 3, 10, 14 );
     placeObject_h("sofa", 2, 13, 14 );
     placeObject_h("shelf", 1, 15, 14 );
     placeObject_h("chair", 2, 16, 14 );

     placeObject_v("chair",1, 18, 3 );
     placeObject_v("sofa",2, 18, 4 );
     placeObject_v("chair",2, 18, 6 );
     placeObject_v("desk",2, 18, 8 );
     placeObject_v("frige",2, 18, 10 );
     placeObject_v("shelf",3, 18, 12 );

     placeObject_h("frige", 1, 9, 3 );
     placeObject_h("sofa", 3, 10, 3 );
     placeObject_h("desk", 2, 13, 3 );
     placeObject_h("shelf", 1, 15, 3 );
     placeObject_h("chair", 2, 16, 3 );

//----------8<x<18-------3<y<14--------------
    //----------中间框内第一列-------------------
     placeObject_v("frige",3, 9, 4 );
     placeObject_v("chair",1, 9, 7 );
     placeObject_v("desk",2, 9, 8 );
     placeObject_v("sofa",1, 9, 11 );
     placeObject_v("desk",2, 9, 12 );
    //------------------中间框内第二列-------------------
     placeObject_v("sofa",1, 10, 5 );
     placeObject_v("frige",3, 10, 6 );
     placeObject_v("desk",2, 10, 10 );
     placeObject_v("shelf",1, 10, 12 );
     placeObject_v("chair",1, 10, 13 );
    //---------中间框内第三列----------------------
     placeObject_v("frige",1, 11, 5 );
     placeObject_v("desk", 3, 11, 8 );
     placeObject_v("chair",2, 11, 12 );
    //--------中间框内第四列---------------------
     placeObject_v("sofa",3, 12, 5 );
     placeObject_v("frige",2, 12, 8 );
     placeObject_v("chair",2, 12, 10 );
    //--------中间框内第四列--------------
     placeObject_v("desk",1, 13, 5 );
     placeObject_v("chair",2, 13, 6 );
     placeObject_v("desk",1, 13, 8 );
     placeObject_v("frige",3, 13, 11 );
    //---------中间框内第五列---------------
     placeObject_v("sofa",2, 14, 4 );
     placeObject_v("desk",1, 14, 7 );
     placeObject_v("frige",3, 14, 9 );
     placeObject_v("chair",2, 14, 12 );
    //---------中间框内第六列-------------------
     placeObject_v("desk",2, 15, 4 );
     placeObject_v("frige",1, 15, 8 );
     placeObject_v("chair",3, 15, 9 );
     placeObject_v("sofa",1, 15, 12 );
     placeObject_v("frige",1, 15, 13 );
    //-------------中间框内第七列-----------------------
     placeObject_v("frige", 3, 16, 4 );
     placeObject_v("sofa", 1, 16, 9 );
     placeObject_v("frige",2, 16, 10 );
     placeObject_v("desk",2, 16, 12 );
    //------------中间框内第八列-----------------------
     placeObject_v("chair",1, 17, 4 );
     placeObject_v("shelf",4, 17, 6 );
     placeObject_v("desk",2, 17, 10 );
     placeObject_v("frige",1, 17, 12 );
     placeObject_v("chair",1, 17, 13 );

    //------------------其他小块（左区）---------------------
    //-----------------line1----------------------------
     placeObject_h("sofa", 3, 0, 5 );
     placeObject_h("chair", 3, 5, 5 );
    //-----------------line2----------------------
     placeObject_h("frige", 1, 1, 6 );
     placeObject_h("shelf", 2, 3, 6 );
     placeObject_h("desk", 2, 6, 6 );
    //-----------------line3------------------------------
     placeObject_h("chair", 4, 1, 7 );
     placeObject_h("frige", 2, 6, 7 );
    //-------------------line4---------------------------
     placeObject_h("chair", 1, 0, 8 );
     placeObject_h("sofa", 1, 1, 8 );
     placeObject_h("desk", 3, 2, 8 );
     placeObject_h("frige", 2, 5, 8 );
    //----------------------line5----------------------
     placeObject_h("desk", 5, 0, 9 );
    //----------------------line6-------------------------
     placeObject_h("frige", 3, 2, 10 );
     placeObject_h("desk", 2, 5, 10 );
     placeObject_h("frige", 1, 7, 10 );
    //-------------------line7--------------------------
     placeObject_h("frige", 3, 0, 11 );
     placeObject_h("shelf", 1, 5, 11 );
    //----------------------line8------------------
     placeObject_h("desk", 1, 4, 12 );
     placeObject_h("chair", 3, 5, 12 );


//--------------------其他小块（右区）--------------------
    //-----------------line1----------------------------
     placeObject_h("desk", 3, 20, 5 );
     placeObject_h("chair", 3, 24, 5 );
    //-----------------line2----------------------
     placeObject_h("frige", 1, 19, 6 );
     placeObject_h("shelf", 2, 22, 6 );
     placeObject_h("desk", 2, 25, 6 );
    //-----------------line3------------------------------
     placeObject_h("chair", 4, 20, 7 );
     placeObject_h("frige", 2, 24, 7 );
    //-------------------line4---------------------------
     placeObject_h("chair", 1, 19, 8 );
     placeObject_h("sofa", 1, 21, 8 );
     placeObject_h("desk", 3, 22, 8 );
     placeObject_h("frige", 2, 25, 8 );
    //----------------------line5----------------------
     placeObject_h("desk", 5, 21, 9 );
    //----------------------line6-------------------------
     placeObject_h("frige", 3, 21, 10 );
     placeObject_h("desk", 2, 24, 10 );
     placeObject_h("frige", 1, 26, 10 );
    //-------------------line7--------------------------
     placeObject_h("frige", 3, 22, 11 );
     placeObject_h("shelf", 1, 26, 11 );
    //----------------------line8------------------
     placeObject_h("desk", 1, 24, 12 );

//--------------其他小块（上区）-----------------------
    //-------line1------------------------------
     placeObject_h("desk", 3, 7, 0 );
     placeObject_h("chair", 2, 13, 0 );
     placeObject_h("shelf", 1, 17, 0 );
     placeObject_h("desk", 2, 20, 0 );
    //-------line2------------------
     placeObject_h("chair", 5, 6, 1 );
     placeObject_h("desk", 3, 14, 1 );
     placeObject_h("sofa", 4, 18, 1 );
    //-----------line3-------------------
     placeObject_h("chair", 3, 15, 2 );
//--------------其他小块（下区）-------------------------
    //-------line3------------------------------
     placeObject_h("desk", 4, 12, 15 );
    //-------line2------------------
     placeObject_h("chair", 3, 8, 16 );
     placeObject_h("desk", 3, 14, 16 );
     placeObject_h("sofa", 4, 18, 16 );
    //-----------line1-------------------
     placeObject_h("chair", 3, 7, 17 );
     placeObject_h("sofa", 2, 13, 17 );
     placeObject_h("shelf", 1, 17, 17 );
     placeObject_h("desk", 2, 20, 17 );

//--------------------音乐-------------
     _BGM.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/pig_BGM.mp3"));
     _BGM.setVolume(80);
     _BGM.play();

     _win.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/win.mp3"));
     _win.setVolume(100);

     _lose.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/lose.mp3"));
     _lose.setVolume(100);

     _placebomb.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/placeBomb.mp3"));
     _placebomb.setVolume(100);

     _explode.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/explode.mp3"));
     _explode.setVolume(100);

     _pigdead.setMedia(QUrl::fromLocalFile("/Users/hewenyu/projects/bubble_room/music_material/pigDead.mp3"));
     _pigdead.setVolume(800);
//---------------背景-----------------
     QImage background;
     background.load("/Users/hewenyu/projects/mole/floor.png");
     _background = background.copy(QRect(0*ICON_br::GRID_SIZE_SET, 0*ICON_br::GRID_SIZE_SET, 36*ICON_br::GRID_SIZE_SET,24*ICON_br::GRID_SIZE_SET));
//------------winning&losing-------------------
     QImage win;
     win.load("/Users/hewenyu/projects/bubble_room/win.jpg");
     _Win = win.copy(QRect(0*ICON_br::GRID_SIZE_SET, 0*ICON_br::GRID_SIZE_SET, 11*ICON_br::GRID_SIZE_SET,11*ICON_br::GRID_SIZE_SET));
     QImage lose;
     lose.load("/Users/hewenyu/projects/bubble_room/game over.jpg");
     _Lose = lose.copy(QRect(0*ICON_br::GRID_SIZE_SET, 0*ICON_br::GRID_SIZE_SET, 12*ICON_br::GRID_SIZE_SET,12*ICON_br::GRID_SIZE_SET));

}

bool World_br::playerBombPlayer(){
    if((_player.getPosX()>=_player.getBomb().getPosX()-1 && _player.getPosX() <= _player.getBomb().getPosX()+1 && _player.getPosY() + 1 == _player.getBomb().getPosY())
            ||(_player.getPosY() + 1 >=_player.getBomb().getPosY()-1 && _player.getPosY()+1 <= _player.getBomb().getPosY()+1 && _player.getPosX() == _player.getBomb().getPosX()))
       return 1;
    else return 0;
}

bool World_br::playerBeBombedBy(Player_br p){
        if((_player.getPosX()>=p.getBomb().getPosX()-1
            && _player.getPosX() <= p.getBomb().getPosX()+1
            && _player.getPosY() + 1 == p.getBomb().getPosY())
                || (_player.getPosY() + 1 >= p.getBomb().getPosY() - 1
            && _player.getPosY()  + 1 <= p.getBomb().getPosY()+1
            && _player.getPosX() == p.getBomb().getPosX()))
           return 1;

         else return 0;
}

bool World_br::pigBeBombed(Player_br p){
    if((p.getPosX()>=_player.getBomb().getPosX()-1 && p.getPosX() <= _player.getBomb().getPosX()+1 && p.getPosY() + 1 == _player.getBomb().getPosY())
            ||(p.getPosY() + 1 >=_player.getBomb().getPosY()-1 && p.getPosY()+1 <= _player.getBomb().getPosY()+1 && p.getPosX() == _player.getBomb().getPosX()))
       return 1;
    else return 0;
}


//解决炸弹重置问题，不然就算已经爆炸完毕走到原地依旧会死
void World_br::show(QPainter * painter){
    static int l_p = 0, w_p = 0;
    if(_player.getIsDead() == 1) {
        _BGM.stop();
        painter->drawImage(700, 300, this->_Lose);
        if(l_p == 1) return;
        _lose.play();
        l_p = 1;
        return;//游戏结束
    }
   if(_pigs.size() == 0) {
       _BGM.stop();
        painter->drawImage(700, 300, this->_Win);
        if(w_p == 1) return;
        _win.play();
        w_p = 1;
       return;
   }
    //以下先画背景
  painter->drawImage(0,0,this->_background);
    //------p弹-layer的炸--------------
    if(MainWindow::count_scs - _player.getPlacetime() <= 2 ){
        _player.getBomb().show(painter);
    }
    if(MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4){
        _explode.play();
        for(int i = 0; i < _objs.size(); i++){
            if((_objs[i].getPosX()>=_player.getBomb().getPosX()-1 && _objs[i].getPosX() <= _player.getBomb().getPosX()+1 && _objs[i].getPosY() == _player.getBomb().getPosY())
                    || (_objs[i].getPosY() >= _player.getBomb().getPosY() - 1 && _objs[i].getPosY() <= _player.getBomb().getPosY()+1 && _objs[i].getPosX() == _player.getBomb().getPosX())){
                if(_objs[i].canBomb() == 1){
                    _objs.erase(_objs.begin()+i);
                }
            }
        }
        _player.getBlast_h().show(painter);
        _player.getBlast_v().show(painter);
        _player.setHasSetBomb(0);
        if(playerBombPlayer() == 1
                && (MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4)){
            //游戏结束—-player炸player
            _player.setDead(1);
            _lose.play();
        }
        for(int t = 0; t < _pigs.size(); t++){//player 炸pig
            if(pigBeBombed(_pigs[t]) == 1 && (MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4)){
                _pigdead.play();
                _pigs[t].setDead(1);
                _pigs.erase(_pigs.begin()+t);
            }
        }
    }
    //---------pig的炸弹------------------
    for(int t = 0; t <_pigs.size(); t++){
        if(MainWindow::count_scs - _pigs[t].getPlacetime() <= 2 ){
            _pigs[t].getBomb().show(painter);
        }
        if(MainWindow::count_scs - _pigs[t].getPlacetime() >2 && MainWindow::count_scs - _pigs[t].getPlacetime() <= 4){
            _explode.play();
            for(int i = 0; i < _objs.size(); i++){
                if(_objs[i].getPosX()>=_pigs[t].getBomb().getPosX()-1 && _objs[i].getPosX() <= _pigs[t].getBomb().getPosX()+1 && _objs[i].getPosY() == _pigs[t].getBomb().getPosY()
                        || _objs[i].getPosY() >= _pigs[t].getBomb().getPosY() - 1 && _objs[i].getPosY() <= _pigs[t].getBomb(). getPosY()+1 && _objs[i].getPosX() == _pigs[t].getBomb().getPosX()){
                    if(_objs[i].canBomb() == 1){
                        _objs.erase(_objs.begin()+i);
                    }
                }
            }
            _pigs[t].getBlast_h().show(painter);
            _pigs[t].getBlast_v().show(painter);
            _pigs[t].setHasSetBomb(0);
            if(playerBeBombedBy(_pigs[t]) == 1
                    && (MainWindow::count_scs - _pigs[t].getPlacetime() >2 && MainWindow::count_scs - _pigs[t].getPlacetime() <= 4)){
                //游戏结束  pig炸player
                _player.setDead(1);
                _lose.play();
            }    
        }
   }

    for(int i = 0; i < _objs.size(); i++){
            _objs[i].show(painter);
    }
    for(int t = 0; t < _pigs.size(); t++){
            _pigs[t].show(painter);
    }

    if(_player.getIsDead() == 1) {
        _player.show(painter);
        return;//游戏结束
    }
    this->_player.show(painter);

}


void World_br::handlePlayerMove(int direction, int steps){
    switch (direction){
        case 1://up
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == -1){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 - 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }
        }

           this->_player.move(direction, steps);
            break;

        case 2://down
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == 16){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 + 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
        this->_player.move(direction, steps);
            break;
        case 3://left
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 0){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1 == _objs[i].getPosY() && this->_player.getPosX() - 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
           this->_player.move(direction, steps);
            break;
        case 4://right
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 26){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1== _objs[i].getPosY() && this->_player.getPosX() + 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }

            }

        }
            this->_player.move(direction, steps);
            break;
        case 5:
            this->_player.move(direction, steps);
            break;
   }
}


void World_br::pigMove(){
    int dir;
    for(int t = 0; t < _pigs.size(); t++){
        if(_pigs[t].getplayerHasSet() == 1) continue;
    //在这里是一段判断自己身边的位置是否是空的代码
        bool te = 1, be = 1, le = 1, re = 1;
        for(int i = 0; i < _objs.size(); i++){
            if((_pigs[t].getPosX() + 1 == _objs[i].getPosX()
                && _pigs[t].getPosY()+1 == _objs[i].getPosY())
              || _pigs[t].getPosX()+1 == 26){
                re = 0;
            }
            if((_pigs[t].getPosX() - 1 == _objs[i].getPosX()
                && _pigs[t].getPosY() + 1 == _objs[i].getPosY() )
              || _pigs[t].getPosX()-1 == -1){
                le = 0;
            }
            if((_pigs[t].getPosY()  == _objs[i].getPosY()
                &&_pigs[t].getPosX() == _objs[i].getPosX() )
              || _pigs[t].getPosY()-1 == -2){
                te = 0;
            }
            if((_pigs[t].getPosY() + 2 == _objs[i].getPosY()
                && _pigs[t].getPosX() == _objs[i].getPosX())
              || _pigs[t].getPosY()+2 == 18){
                be = 0;
            }
        }
    //----------先判断上下位置-----------------
        int has_moved  = 0, rd = 0;
        if(_player.getPosY()<_pigs[t].getPosY() && te == 1){
            dir = 1;
            has_moved = 1;
        }
        else if(_player.getPosY()>_pigs[t].getPosY() && be == 1){
            dir = 2;
            has_moved = 1;
        }
        else{
             dir = 5;
             rd++;
        }
        _pigs[t].move(dir,1);
        if(has_moved == 1) return;
    //---------------再判断左右位置-----------------//拐弯处再作修改

        if(_player.getPosX()<_pigs[t].getPosX() && le == 1){
            dir = 3;

          }
        else if(_player.getPosX()>_pigs[t].getPosX() && re == 1){
            dir = 4;

        }
        else{
            dir = 5;
            rd++;
        }
       _pigs[t].move(dir,1);

     //-------------放置炸弹--------------------
        if(rd == 2){
            _pigs[t].placeBomb();
            _placebomb.play();
            _pigs[t].setHasSetBomb(1);

        }
    }
}


int World_br::getobjX(int i){
    return _objs[i].getPosX();
}

int World_br::getobjY(int i){
    return _objs[i].getPosY();
}

bool World_br::getCanCover(int i){
    return _objs[i].canCover();
}

bool World_br::getCanEat(int i){
    return _objs[i].canEat();
}


