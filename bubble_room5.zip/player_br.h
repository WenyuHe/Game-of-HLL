#ifndef PLAYER_BR_H
#define PLAYER_BR_H
#include "rpgobj_br.h"
#include"object_br.h"
class Player_br: public RPGObj_br
{
public:
    Player_br():_has_set_boom(0){}
    ~Player_br(){}
    void move(int direction, int steps=1);
    void setHasSetBomb(bool i){this->_has_set_boom = i;}
    bool getplayerHasSet(){return this->_has_set_boom;}
    int getPlacetime(){return this->placeTime;}
    void placeBomb();
    bool getIsDead(){return this->dead;}
    void setDead(bool d){this->dead = d;}


    Object_br getBomb(){return this->bomb;}
    Object_br getBlast_h(){return this->blast_h;}
    Object_br getBlast_v(){return this->blast_v;}

        //direction =1,2,3,4 for 上下左右

private:
       bool _has_set_boom;
       Object_br bomb, blast_h, blast_v;
       int placeTime = -100;
       bool dead = 0;

};


#endif // PLAYER_BR_H
