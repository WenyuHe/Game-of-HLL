#include "icon_br.h"
#include<iostream>
int ICON_br::GRID_SIZE_SET = 32;

pair<string,ICON_br> pairArray[] =
{
    make_pair("player",ICON_br("player",2,0, 1, 2)),
    make_pair("player_c",ICON_br("player_c",0,0, 2, 2)),
    make_pair("pig1",ICON_br("pig1",3,0, 1, 2)),
    make_pair("pig2",ICON_br("pig2",4,0, 1, 2)),
    make_pair("pig3",ICON_br("pig3",3,0, 1, 2)),
    make_pair("sofa",ICON_br("sofa",1,3,1,1)),
    make_pair("chair",ICON_br("chair",3,2,1,1)),
    make_pair("frige",ICON_br("frige",0,3,1,1)),
    make_pair("bomb",ICON_br("bomb",0,2,1,1)),
    make_pair("blast_h",ICON_br("blast_h",0,4,3,1)),
    make_pair("blast_v",ICON_br("blast_v",5,0,1,3)),
    make_pair("cake",ICON_br("cake",1,2,1,1)),
     make_pair("desk",ICON_br("desk",4,2,1,1)),
     make_pair("shelf",ICON_br("shelf",3,3,1,1)),
};

map<string,ICON_br> ICON_br::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON_br::ICON_br(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->ScrX = x;
    this->ScrY = y;
    this->width = w;
    this->height = h;
}

ICON_br ICON_br::findICON(string type){
    map<string,ICON_br>::iterator kv;
    kv = ICON_br::GAME_ICON_SET.find(type);
    if (kv==ICON_br::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON_br();
    }
    else{
        return kv->second;
    }
}
