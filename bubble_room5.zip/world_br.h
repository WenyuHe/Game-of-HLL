/*
 现在1.自己可以炸死自己
 2.小猪只有恰好踩在炸弹上才会死
 3.不能被猪炸死
4.有一只小猪可以踩上桌子？？？？
*/
#ifndef WORLD_BR_H
#define WORLD_BR_H
#include "rpgobj_br.h"
#include <vector>
#include <string>
#include <QPainter>
#include<QLabel>
#include "player_br.h"
#include"object_br.h"
#include<QTimer>
#include<QImage>
#include<QRectF>
#include<QMediaPlayer>

class World_br
{
public:
    World_br(){}
    ~World_br(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    void pigMove();

    int getobjX(int i);
    int getobjY(int i);
    bool getCanCover(int i);
    bool getCanBomb(int i);
    bool getCanEat(int i);
    Player_br getPlayer(){return this->_player;}

    void resetHasStoped(){ this->has_stoped = 0;}
    int getStopped(){return this->stopped;}
    void playerPlaceBomb(){
        this->_player.placeBomb();
        _placebomb.play();
    }

    RPGObj_br getObjects(int i){return _objs[i];}

    bool pigBeBombed(Player_br p);
    bool playerBeBombedBy(Player_br p);
   // bool playerBeBombed();//遍历
    bool playerBombPlayer();
    static bool has_eaten;


    void placeObject_h(string obj, int length, int posX, int posY);
    void placeObject_v(string obj, int length, int posX, int posY);
    //假定只有一个玩家
private:
   vector<RPGObj_br>_objs;
   vector<Player_br> _pigs;
    Player_br _player;
    QTimer timer0;
    int has_stoped = 0, stopped = 0;
    QImage _background;
    QImage _Win, _Lose;
    QMediaPlayer _BGM, _win, _lose, _placebomb, _explode, _pigdead;
};

#endif // WORLD_BR_H
