#ifndef OBJECT_BR_H
#define OBJECT_BR_H
#include "rpgobj_br.h"
class Object_br: public RPGObj_br {
public:
    bool getHasExploded();
private:
    bool _has_exploded;

};

#endif // OBJECT_BR_H
