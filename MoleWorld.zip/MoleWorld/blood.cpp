#include "blood.h"
#include<iostream>
using namespace std;
int Blood::GRID_SIZE=32;
Blood::Blood()
{
    this->_all.load("C:\\blood.png");
}

Blood::~Blood()
{

}

void Blood::setblood(int n)
{
    _blood-=n;
    cout<<"blood:"<<_blood<<endl;
}

void Blood::show(QPainter* painter)
{
    if(this->_blood<=0)
    {
        return ;
    }
    else if(_blood==1000)
    {
        this->_pic = this->_all.copy(QRect(0, 0, 4*GRID_SIZE, 2*GRID_SIZE));
        painter->drawImage(_pos_x*GRID_SIZE,this->_pos_y*GRID_SIZE,this->_pic);
    }
    else
    {
        this->_pic = this->_all.copy(QRect((9-this->_blood/100)*0.4*GRID_SIZE, 0, 0.4*(_blood/100+1)*GRID_SIZE, 2*GRID_SIZE));
        painter->drawImage((_pos_x+(9-this->_blood/100)*0.4)*GRID_SIZE,this->_pos_y*GRID_SIZE,this->_pic);
    }

}
