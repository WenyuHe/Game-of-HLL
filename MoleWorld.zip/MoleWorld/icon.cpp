#include "icon.h"
#include<iostream>
using namespace std;
int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("mole",ICON("mole",0,8,4.5,8)),
    make_pair("ghost",ICON("ghost",4.5,8,5,8)),
    make_pair("fire",ICON("fire",6,0,2,4)),
    make_pair("water",ICON("water",0,4,5,4)),
    make_pair("indian1",ICON("indian1",0,0,2,4)),
    make_pair("indian2",ICON("indian2",2,0,2,4)),
   // make_pair("blood",ICON("blood",5.45,4.75,5,2))
};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, double x, double y, double w,double h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){
       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
