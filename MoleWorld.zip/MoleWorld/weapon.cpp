#include "weapon.h"

Weapon::Weapon()
{

}

Weapon::Weapon(string type,int n)
{
    this->initObj(type);
    this->min=n;
}

void Weapon::setmin(int n){
    this->min-=n;
    cout<<"min:"<<min<<endl;
}
