#include "world.h"
#include "icon.h"
#include <iostream>
#include <fstream>
using namespace std;
void World::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5
    ifstream fp(mapFile);
    string type;
    int x,y;

    fp>>type>>x>>y;
    this->_mole.initObj(type);
    this->_mole.setPosX(x);
    this->_mole.setPosY(y);
    this->_mole.initblood(1000);
    this->_mole.initpower(10);

    fp>>type>>x>>y;
    this->_ghost.initObj(type);
    this->_ghost.setPosX(x);
    this->_ghost.setPosY(y);
    this->_ghost.initblood(1000);
    this->_ghost.initpower(20);
}


void World::show(QPainter * painter){
    vector<Weapon>::iterator it;
    for(it=this->_water.begin();it!=this->_water.end();it++){
        (*it).show(painter);
    }
    for(it=this->_fire.begin();it!=this->_fire.end();it++){
        (*it).show(painter);
    }
    for(it=this->_indian.begin();it!=this->_indian.end();it++){
        (*it).show(painter);
    }
    this->_mole.show(painter);
    this->_ghost.show(painter);
}

void World::handleFireMove(){
    if(_fire.empty())
    {
        cout<<"Fire is empty!"<<endl;
        return ;
    }
    //移动fire
    vector<Weapon>::iterator it;
    for(it=_fire.begin();it!=_fire.end();it++)
    {
        it->move(3,5);
    }

    //判断fire是否与mole相遇
    it=_fire.begin();
    if(it->getPosX()<=_mole.getPosX()+4.5)
        {
            _mole.setblood(it->getmin());
            _fire.erase(it);
            _mole.setpower(_mole.getblood()/100);
        }
    //判断fire是否与water相遇
    if(_water.empty())
    {
        return;
    }
    it=_fire.begin();
    vector<Weapon>::iterator water;
    water=_water.begin();
    if (it->getPosX()<=water->getPosX())
    {
        int nf=it->getmin();
        int nw=water->getmin();
        cout<<nf<<" "<<nw<<endl;
        if(nf>nw)
        {
            _water.erase(water);
            it->setmin(nw);
        }
        else if(nf==nw)
        {
            _water.erase(water);
            _fire.erase(it);
        }
        else
        {
            _fire.erase(it);
            water->setmin(nf);
        }
    }
}

void World::ghost2fire()
{
    Weapon fire;
    fire=_ghost.usefire();
    fire.setPosX(54);
    fire.setPosY(22);
    this->_fire.push_back(fire);
}

void World::handleWaterMove()
{
    if(_water.empty())
    {
        cout<<"Water is empty!"<<endl;
        return ;
    }
    vector<Weapon>::iterator it;
    for(it=_water.begin();it!=_water.end();it++)
    {
        it->move(4,6);
    }
    //判断mole是否与ghost相遇
    it=_water.begin();
    if(it->getPosX()+5>=_ghost.getPosX())
    {
        _ghost.setblood(it->getmin());
        _water.erase(it);
        _ghost.setpower(2*_ghost.getblood()/100);
    }
}

void World::handleIndianMove()
{
    if(_indian.empty())
    {
        cout<<"Indian is empty!"<<endl;
        return ;
    }
    vector<Weapon>::iterator it;
    for(it=_indian.begin();it!=_indian.end();it++)
    {
        it->move(4,3);
    }
    it=_indian.begin();
    if(it->getPosX()>=_ghost.getPosX())
    {
        _ghost.setblood(it->getmin());
        _indian.erase(it);
        _ghost.setpower(2*_ghost.getblood()/100);
    }
}

void World::mole2water()
{
    Weapon water;
    water=_mole.usewater();
    water.setPosX(9);
    water.setPosY(22);
    this->_water.push_back(water);
}

void World::mole2indian()
{
    Weapon indian;
    indian=_mole.useindian();
    indian.setPosX(9);
    indian.setPosY(26);
    this->_indian.push_back(indian);
}
