#ifndef WEAPON_H
#define WEAPON_H
#include "rpgobj.h"
#include <iostream>
using namespace std;

class Weapon:public RPGObj
{
public:
    Weapon();
    Weapon(string type,int n);
    void setmin(int n);
    int getmin(){return min;}
private:
    int min;
};

#endif // WEAPON_H
