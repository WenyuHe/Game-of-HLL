#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTimer>
#include <map>
#include <iostream>
#include <QMessageBox>
#include <QtGui>
using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("C:\\MoleWorld\\map.txt");//TODO 应该是输入有效的地图文件

    //以下是对时钟的初始化

    genefiretimer = new QTimer(this);
    connect(genefiretimer,SIGNAL(timeout()),this,SLOT(GenerateFire()));
    genefiretimer->start(1000);

    firetimer = new QTimer(this);
    connect(firetimer,SIGNAL(timeout()),this,SLOT(MoveFire()));
    firetimer->start(1000);

    watertimer = new QTimer(this);
    connect(watertimer,SIGNAL(timeout()),this,SLOT(MoveWater()));
    watertimer->start(1000);

    indiantimer = new QTimer(this);
    connect(indiantimer,SIGNAL(timeout()),this,SLOT(MoveIndian()));
    indiantimer->start(1000);
    //qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawPixmap(0,0,36*ICON::GRID_SIZE,24*ICON::GRID_SIZE,QPixmap("C:\\MoleWorld\\background.png"));
    this->_game.show(pa);
    pa->end();
    delete pa;
}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_W)
    {
        this->_game.mole2water();
        if(this->_game.handleWaterMove()==true)
        {
            QMessageBox box;
            box.about(this,"Warning","You win!");
            exit(0);
        }
    }
    else if(e->key() == Qt::Key_I)
    {
        this->_game.mole2indian();
        if(this->_game.handleIndianMove()==true)
        {
            QMessageBox box;
            box.about(this,"Warning","You win!");
            exit(0);
        }
    }
    this->repaint();
}

void MW1::MoveFire(){
    this->_game.handleFireMove();
    if(this->_game.handleFireMove()==true)
    {
        cout<<"!"<<endl;
        QMessageBox box;
        box.about(this,"Warning","Game Over!");
        exit(0);
    }
    this->repaint();
}

void MW1::GenerateFire(){
    this->_game.ghost2fire();
    this->repaint();
}

void MW1::MoveWater(){
    this->_game.handleWaterMove();
    if(this->_game.handleWaterMove()==true)
    {
        QMessageBox box;
        box.about(this,"Warning","You win!");
        exit(0);
    }
    this->repaint();
}

void MW1::MoveIndian(){
    this->_game.handleIndianMove();
    if(this->_game.handleIndianMove()==true)
    {
        QMessageBox box;
        box.about(this,"Warning","You win!");
        exit(0);
    }
    this->repaint();
}
