#ifndef SOLDIER_H
#define SOLDIER_H
#include "rpgobj.h"
#include <iostream>
using namespace std;

class Soldier:public RPGObj
{
public:
    Soldier();
    ~Soldier();
    int getblood(){return blood;}
    int getpower(){return power;}
    void initblood(int n);
    void initpower(int n);
    void setblood(int n);
    void setpower(int n);
private:
    int blood;
    int power;
};

#endif // SOLDIER_H
