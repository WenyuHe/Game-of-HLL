#include "ghost.h"

Ghost::Ghost()
{
}

Ghost::~Ghost()
{

}

Weapon Ghost::usefire()
{
    Weapon fire("fire",this->getpower());
    return fire;
}
