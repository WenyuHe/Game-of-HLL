#include "soldier.h"

Soldier::Soldier()
{

}

Soldier::~Soldier()
{

}

void Soldier::initblood(int n)
{
    blood=n;
}

void Soldier::initpower(int n)
{
    power=n;
}

void Soldier::setblood(int n)
{
    blood-=n;
    cout<<"blood:"<<blood<<endl;
}

void Soldier::setpower(int n)
{
    power=n;
    cout<<"power:"<<power<<endl;
}
