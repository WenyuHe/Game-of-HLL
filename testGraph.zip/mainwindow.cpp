#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //m=new QMovie;
    //label=new QLabel;
        //m->setFileName("/Users/hewenyu/pocha.gif");
        //m->setSpeed(100);//这里设置播放速度，主要是为了看清楚暂停和继续有没有成功执行
        //label->setMovie(m);
        //m->start();//开始播放
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    QImage all;
    all.load("/Users/hewenyu/projects/QTMap/pilee.png");
    QImage Indian1 = all.copy(QRect(0*32, 0*32, 2*32, 4*32));
    pa->drawImage(0*32,1*32,Indian1);
    pa->end();
    //m->setFileName("/Users/hewenyu/pocha.gif");
   //m->setSpeed(100);//这里设置播放速度，主要是为了看清楚暂停和继续有没有成功执行
    //label->setMovie(m);
    //m->start();//开始播放
    delete pa;
}
