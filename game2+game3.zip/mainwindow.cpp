#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "icon.h"
#include <QTimer>
#include <map>
#include <iostream>
#include <fstream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    now(3),game1(0),game2(0),game3(0),
    ui(new Ui::MainWindow)

{
    ui->setupUi(this);
    ifstream fin("/Users/hewenyu/projects/mole/map.txt");
    fin>>game1>>game2>>game3;
    fin.close();
    //init games world
    _game3.initWorld3("/Users/hewenyu/projects/mole/map3.txt");//todo
    _game2.initWorld2("/Users/hewenyu/projects/mole/map2.txt");//todo
//-------------------timer of game2-----------------------
    genefiretimer = new QTimer(this);
    connect(genefiretimer,SIGNAL(timeout()),this,SLOT(GenerateFire()));
    //genefiretimer->start(1000);

    firetimer = new QTimer(this);
        connect(firetimer,SIGNAL(timeout()),this,SLOT(MoveFire()));
        //firetimer->start(1000);

        watertimer = new QTimer(this);
        connect(watertimer,SIGNAL(timeout()),this,SLOT(MoveWater()));
        //watertimer->start(1000);

        indiantimer = new QTimer(this);
        connect(indiantimer,SIGNAL(timeout()),this,SLOT(MoveIndian()));
        //indiantimer->start(1000);
//-------------------timer of game3-----------------------
     fishtimer = new QTimer(this);
    connect( fishtimer,SIGNAL(timeout()),this,SLOT(fishOn()));
     fishtimer->setInterval(500);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){//TODO make up
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if(now==3){
        this->_game3.show(pa);//todo?
    }else if(now==2){
        this->_game2.show(pa);
    }

    pa->end();
    delete pa;
}

void MainWindow::keyPressEvent(QKeyEvent *e)//TODO make up
{
    //direction = 1,2,3,4 for 上右下左
    if(e->key() == Qt::Key_A)
    {
        if(this->now==3){
            this->_game3.handlePlayerMove(4,1);
            if(this->_game3.getFishCount()==4){
                this->_game3.handleFishMove(4,1);
            }
        }
    }
    else if(e->key() == Qt::Key_D)
    {
        if(this->now==3){
            this->_game3.handlePlayerMove(2,1);
            if(this->_game3.getFishCount()==4){
                this->_game3.handleFishMove(2,1);
            }
        }
    }
    else if(e->key() == Qt::Key_W)
    {
        if(this->now==2){
            this->_game2.mole2water();
            if(this->_game2.handleWaterMove()==true)
            {
                QMessageBox box;
                box.about(this,"Warning","You win!");
                finishGame2(1);
            }
        }
        if(this->now==3){
        this->_game3.handlePlayerMove(1,1);
        if(this->_game3.getFishCount()==4){
            this->_game3.handleFishMove(1,1);
        }
        }

    }
    else if(e->key() == Qt::Key_S)
    {
        if(this->now==3){
         this->_game3.handlePlayerMove(3,1);
        if(this->_game3.getFishCount()==4){
            this->_game3.handleFishMove(3,1);
        }
        }
    }
    else if(e->key() == Qt::Key_B)//TODO 存档
    {
        this->save();
    }
    else if(e->key() == Qt::Key_F)//may change
    {
        if(this->now==3){
        this->fishing();
        this->_game3.putFish();
        this->_game3.memeTalk(this);
        }
    }
    else if(e->key() == Qt::Key_I)
    {
        if(this->now==2){
        this->_game2.mole2indian();
        if(this->_game2.handleIndianMove()==true)
        {
            QMessageBox box;
            box.about(this,"Warning","You win!");
            finishGame2(1);
        }
        }
    }
    checkWorld();
    this->repaint();
}

void MainWindow::checkWorld()
{
    if(now==3&&this->_game3.getPlayerX()==19&&this->_game3.getPlayerY()==9&&game2==0){
        now=2;
        genefiretimer->start(1000);
        firetimer->start(1000);
        watertimer->start(1000);
        indiantimer->start(1000);
        return;
    }else if(now==3&&this->_game3.getPlayerX()==19&&this->_game3.getPlayerY()==9&&game2==1){
        QMessageBox box;
        box.about(this,"Warning","你已经完成这个游戏了哦^-^");
    }
    if(now==3&&this->_game3.getPlayerX()==31&&this->_game3.getPlayerY()==10){
        now=1;
        return;
    }
}

void MainWindow::save()
{
    ofstream fout("/Users/hewenyu/projects/mole/map.txt");
    fout<<game1<<endl<<game2<<endl<<game3<<endl;
    fout.close();
    this->_game3.save("/Users/hewenyu/projects/mole/map3.txt");
}

void MainWindow::finishGame2(int result)
{
    now=3;
    game2=result;
    genefiretimer->stop();
    firetimer->stop();
    watertimer->stop();
    indiantimer->stop();
}

void MainWindow::receivelogin()
{
    this->show();//显示主窗口
}
//-----------------game2----------------------
void MainWindow::MoveFire(){
    this->_game2.handleFireMove();
    if(this->_game2.handleFireMove()==true)
    {
        cout<<"!"<<endl;
        QMessageBox box;
        box.about(this,"Warning","Game Over!");
        finishGame2(0);
    }
    this->repaint();
}

void MainWindow::GenerateFire(){
    this->_game2.ghost2fire();
    this->repaint();
}

void MainWindow::MoveWater(){
    this->_game2.handleWaterMove();
    if(this->_game2.handleWaterMove()==true)
    {
        QMessageBox box;
        box.about(this,"Warning","You win!");
        finishGame2(1);
    }
    this->repaint();
}

void MainWindow::MoveIndian(){
    this->_game2.handleIndianMove();
    if(this->_game2.handleIndianMove()==true)
    {
        QMessageBox box;
        box.about(this,"Warning","You win!");
        finishGame2(1);
    }
    this->repaint();
}
//-----------------------game3------------------------
void MainWindow::fishing()
{
    if(this->_game3.getPlayerX()!=12||this->_game3.getPlayerY()!=17){
        return;
    }
     fishtimer->start();
}

void MainWindow::fishOn(){

    this->_game3.changeFish();
    this->repaint();
    if(_game3.getFishCount()==4){
         fishtimer->stop();
    }

}
//----------------------temporarily useless------------
void MainWindow::randomMove(){
    int e = (1 + rand()%2)*2;
    //this->_game3.handleMonsterMove(e,1);
    this->repaint();
}
