#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world2.h"
#include "world3.h"
#include<QTime>
#include<QTimer>
#include <QMessageBox>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);
    void checkWorld();
    void save();
    void finishGame2(int result);
    //void straightMove();
    //static int count_scs;
private slots:
    void receivelogin();//与login中发射的信号关联的槽函数
protected slots:
    //void countTime();
    //void pigMove();

    void randomMove();
    void fishOn();

    void MoveFire();
    void GenerateFire();
    void MoveWater();
    void MoveIndian();
private:
    void fishing();
    int now,game1,game2,game3;
    Ui::MainWindow *ui;
    //World_br _game;
    World2 _game2;
    World3 _game3;
    QTimer *fishtimer;

    QTimer * firetimer;
    QTimer * watertimer;
    QTimer * indiantimer;
    QTimer * genefiretimer;
/*
    QTimer *timer0;
    QTimer *timer1;
    QTimer *timer2;
    QTimer *timer3;
    int dir;
    QLabel *label;*/
        //时钟，控制玩家移动频率
};

#endif // MAINWINDOW_H
