#ifndef SOLDIER_H
#define SOLDIER_H
#include "rpgobj.h"
#include <iostream>
using namespace std;

class Soldier:public RPGObj
{
public:
    Soldier();
    ~Soldier();
    int getpower(){return power;}
    void initpower(int n);
    void setpower(int n);
private:
    int power;
};

#endif // SOLDIER_H
