#ifndef WORLD3_H
#define WORLD3_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "fish.h"
#include <QMessageBox>
//#include "mainwindow.h"
class QWidget;
class World3
{
public:
    World3();
    ~World3(){}
    void initWorld3(string mapFile);
    void show(QPainter * painter);//显示游戏世界所有对象
    void save(string mapFile);

    double getPlayerX();
    double getPlayerY();//假定只有一个玩家
    void handlePlayerMove(int direction, int steps);

    void changeFish();
    int getFishCount();
    void putFish();
    void handleFishMove(int direction, int steps);

    void memeTalk(QWidget * mw);
private:
    int fishPut,memeChange;
    vector<RPGObj> _objs;
    vector<RPGObj> _pig;
    Player _player;
    Fish _fish;
    QImage _map,fishBasket;

};

#endif // WORLD3_H
