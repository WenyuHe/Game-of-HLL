#include "mydialog.h"
#include "ui_mydialog.h"

Mydialog::Mydialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Mydialog)
{
    ui->setupUi(this);
    setWindowTitle(tr("Mole Login"));
    QWidget::move(0,0);
    QImage bg;
    bg.load("/Users/hewenyu/projects/mole/login.png");
    _bg = bg.copy(QRect(0*32, 0*32, 40*32, 24*32));

}

Mydialog::~Mydialog()
{
    delete ui;
}
void Mydialog::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    pa->drawImage(0,0,_bg);
    pa->end();
    delete pa;
}
void Mydialog::on_pushButton_clicked()
{
    this->hide();//隐藏登录对话框
    emit showmainwindow();//显示主窗口
}

void Mydialog::on_pushButton_2_clicked()
{
    emit quit();//发射退出信号
}
