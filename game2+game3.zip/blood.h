#ifndef BLOOD_H
#define BLOOD_H
#include <QPainter>
#include <QImage>

class Blood
{
public:
    static int GRID_SIZE;
    Blood();
    ~Blood();
    void setPosX(double x){this->_pos_x=x;}
    void setPosY(double y){this->_pos_y=y;}
    void initblood(int n){this->_blood=n;}
    int getblood() {return this->_blood;}
    void setblood(int n);
    void show(QPainter* painter);
private:
   int _blood;
   QImage _all,_pic;
   double _pos_x,_pos_y;
};

#endif // BLOOD_H
