#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    int game=0;
    //TODO 所支持的对象类型应定义为枚举
    //只有game3的对象需要判断
    if (type.compare("player")==0||type.compare("fish")==0
            ||type.compare("pig1")==0||type.compare("pig2")==0
            ||type.compare("pig3")==0||type.compare("pig4")==0
            ||type.compare("meme")==0){
        this->_coverable = false;
        this->_eatable = false;
        game=3;
    }
    else if (type.compare("basket")==0){
        this->_coverable = true;
        this->_eatable = false;
        game=3;
    }
    else if (type.compare("candy")==0){
        this->_coverable = true;
        this->_eatable = true;
        game=3;
    }
    else{
        game=2;
    }

    this->_icon = Icon::findIcon(type);

    QImage all;
    if(game==2){
        all.load("/Users/hewenyu/projects/MoleWorld-2/molebeat.png");
    }
    else if(game==3){
        all.load("/Users/hewenyu/projects/mole/all.png");
    }
    this->_pic = all.copy(QRect(_icon.getSrcX()*Icon::GRID_SIZE, _icon.getSrcY()*Icon::GRID_SIZE, _icon.getWidth()*Icon::GRID_SIZE, _icon.getHeight()*Icon::GRID_SIZE));
}

void RPGObj::show(QPainter * pa){
    int gSize = Icon::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}

//direction =1,2,3,4 for 上右下左
void RPGObj::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            break;
        case 2:
            this->_pos_x += steps;
            break;
        case 3:
            this->_pos_y += steps;
            break;
        case 4:
            this->_pos_x -= steps;
            break;
    }
}

