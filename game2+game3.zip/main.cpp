#include "mainwindow.h"
#include <QApplication>
#include"mydialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Mydialog dlg;
    dlg.show();
    //信号与槽之间进行关联
    QObject::connect(&dlg,SIGNAL(showmainwindow()),&w,SLOT(receivelogin()));
    QObject::connect(&dlg,SIGNAL(quit()),&a,SLOT(quit()));
    //w.show();

    return a.exec();
}
