#include "icon.h"
#include<iostream>
int Icon::GRID_SIZE = 32;


pair<string,Icon> pairArray[] =//string和图标初始化对应
{
    make_pair("player",Icon("player",0,0, 1, 2)),
    make_pair("basket",Icon("basket",1,0, 1, 1)),
    make_pair("candy",Icon("candy",2,1, 1, 1)),
    make_pair("fish",Icon("fish",1,1, 1, 1)),
    make_pair("pig1",Icon("pig1",0,2, 2, 2)),
        make_pair("pig2",Icon("pig2",2,2, 2, 2)),
        make_pair("pig3",Icon("pig3",0,4, 2, 2)),
        make_pair("pig4",Icon("pig4",2,4, 2, 2)),
        make_pair("meme",Icon("meme",3,0, 1.3, 2)),
        make_pair("mole",Icon("mole",0,8,4.5,8)),//todo:change name
        make_pair("ghost",Icon("ghost",4.5,8,5,8)),
        make_pair("fire",Icon("fire",6,0,2,4)),
        make_pair("water",Icon("water",0,4,5,4)),
        make_pair("indian1",Icon("indian1",0,0,2,4)),
        make_pair("indian2",Icon("indian2",2,0,2,4)),

};

map<string,Icon> Icon::GAME_Icon_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


Icon::Icon(string name, double x, double y, double w, double h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

Icon Icon::findIcon(string type){
    map<string,Icon>::iterator kv;
    kv = Icon::GAME_Icon_SET.find(type);
    if (kv==Icon::GAME_Icon_SET.end()){
       cout<<"Error: cannot find Icon"<<endl;
       return Icon();
    }
    else{
        return kv->second;
    }
}
