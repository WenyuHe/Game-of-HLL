#ifndef RPGOBJ_H
#define RPGOBJ_H
#include <QImage>
#include <QPainter>
#include <string>
#include <icon.h>
#include <map>
using namespace std;

class RPGObj
{
public:
    RPGObj(){}
    ~RPGObj(){}

    void initObj(string type);
    void show(QPainter * painter);

    void setPosX(double x){this->_pos_x=x;}
    void setPosY(double y){this->_pos_y=y;}

    double getPosX() const{return this->_pos_x;}
    double getPosY() const{return this->_pos_y;}
    double getHeight() const{return this->_Icon.getHeight();}
    double getWidth() const{return this->_Icon.getWidth();}
    string getObjType() const{return this->_Icon.getTypeName();}//返回类名

    bool canCover() const{return this->_coverable;}
    bool canEat() const{return this->_eatable;}

    void move(int direction, int steps=1);
        //direction =1,2,3,4 for 上右下左


protected:
    //所有坐标，单位均为游戏中的格

    QImage _pic;
    double _pos_x, _pos_y;//该物体在游戏中当前位置（左上角坐标）
    Icon _Icon;//可以从Icon中获取对象的素材，尺寸等信息
    bool _coverable;
    bool _eatable;
};

#endif // RPGOBJ_H
