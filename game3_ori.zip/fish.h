#ifndef FISH_H
#define FISH_H
#include "rpgobj.h"
#include <QTimer>

class Fish:public RPGObj
{
public:
    Fish();
    ~Fish(){}
    void show(QPainter * painter);
    int getfishCount();
    void putFish();
    void changefishCount();
private:
    int fishCount;
    QImage _fish[3];
};

#endif // FISH_H
