#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "icon.h"
#include <QTimer>
#include <map>
#include <iostream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("/Users/hewenyu/projects/mole/map.txt");//todo

    //以下是对时钟的初始化
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(fishOn()));
    timer->setInterval(500);

    //qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子*/
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);//todo
    pa->end();
    delete pa;
}

void MainWindow::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上右下左
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(4,1);
        if(this->_game.getFishCount()==4){
            this->_game.handleFishMove(4,1);
        }
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(2,1);
        if(this->_game.getFishCount()==4){
            this->_game.handleFishMove(2,1);
        }
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
        if(this->_game.getFishCount()==4){
            this->_game.handleFishMove(1,1);
        }
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(3,1);
        if(this->_game.getFishCount()==4){
            this->_game.handleFishMove(3,1);
        }
    }
    else if(e->key() == Qt::Key_B)//存档
    {
         this->_game.save("/Users/hewenyu/projects/mole/map.txt");
    }
    else if(e->key() == Qt::Key_F)//may change
    {
        this->fishing();
        this->_game.putFish();
    }
    this->repaint();
}
//-----------------------other------------------------
void MainWindow::fishing()
{
    if(this->_game.getPlayerX()!=12||this->_game.getPlayerY()!=17){
        return;
    }
    timer->start();
}

void MainWindow::fishOn(){
    this->_game.changeFish();
    this->repaint();
    if(_game.getFishCount()==4){
        timer->stop();
    }

}

void MainWindow::randomMove(){
    int e = (1 + rand()%2)*2;
    //this->_game.handleMonsterMove(e,1);
    this->repaint();
}
