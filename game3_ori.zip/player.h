#ifndef PLAYER_H
#define PLAYER_H
#include "rpgobj.h"

class Player: public RPGObj
{
public:
    Player(){}
    ~Player(){}
};

#endif // PLAYER_H
