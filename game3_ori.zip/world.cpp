#include "world.h"
#include "icon.h"
#include <fstream>
#include <string>

World::World():game3(0),fishPut(0){}

void World::initWorld(string mapFile){
    //读入地图文件，生成地图上的对象
    ifstream fin(mapFile);
    string type;
    RPGObj obj;
    int x=0,y=0;
    while(!fin.eof()){
        fin>>type>>x>>y;
        if(type=="player"){
            this->_player.initObj("player");
            this->_player.setPosX(x);
            this->_player.setPosY(y);
        }else if(type=="candy"||type=="basket"){
            obj.initObj(type);
            obj.setPosX(x);
            obj.setPosY(y);
            this->_objs.push_back(obj);
        }else if(type=="fish"){
            this->_fish.initObj(type);
            this->_fish.setPosX(x);
            this->_fish.setPosY(y);
        }
    }
    fin.close();
    QImage map,all;
    map.load("/Users/hewenyu/projects/mole/street.png");
    _map = map.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE, 24*Icon::GRID_SIZE));
    all.load("/Users/hewenyu/projects/mole/all.png");
    fishBasket = all.copy(QRect(2*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 1*Icon::GRID_SIZE, 1*Icon::GRID_SIZE));
}
//-------------------fishing begin------------------
void World::changeFish(){
    _fish.changefishCount();
}

int World::getFishCount(){
    return _fish.getfishCount();
}

void World::putFish()
{
    if(this->getPlayerX()!=32||this->getPlayerY()!=14){
        return;//change with basket place in map.txt
    }
    fishPut=1;
}
//--------------------fishing end---------------------
void World::show(QPainter * painter){
    painter->drawImage(0,0,this->_map);
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
    if(fishPut){//change with basket place in map.txt
        painter->drawImage(32*Icon::GRID_SIZE,15*Icon::GRID_SIZE,this->fishBasket);
    }
    this->_player.show(painter);
    if(fishPut==0){
        this->_fish.show(painter);
    }
}

void World::handlePlayerMove(int direction, int steps){
    this->_player.move(direction, steps);
    int all=_objs.size(),oppo=(direction-2>0)?direction-2:direction+2;
    for(int i=0;i<all;i++){
        if(_objs[i].canEat()&&_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==(_player.getPosY()+1)){
            this->_objs.erase(_objs.begin()+i);//to check
            continue;
        }
        if((!_objs[i].canCover())
                &&(_objs[i].getPosX()+_objs[i].getWidth()-1)>=_player.getPosX()&&_objs[i].getPosX()<=_player.getPosX()
                &&(_objs[i].getPosY()+_objs[i].getHeight()-1)>=(_player.getPosY()+1)&&_objs[i].getPosY()<=(_player.getPosY()+1)){
            this->_player.move(oppo, steps);
            continue;
        }
        if(_player.getPosY()>19||_player.getPosY()<8||_player.getPosX()<6||_player.getPosX()>34){//x:6~29 y:8~19
            this->_player.move(oppo, steps);
            continue;
        }

    }
}

void World::handleFishMove(int direction, int steps)
{
    this->_fish.move(direction, steps);
    int all=_objs.size(),oppo=(direction-2>0)?direction-2:direction+2;
    for(int i=0;i<all;i++){
        if(_objs[i].canEat()&&_objs[i].getPosX()==_fish.getPosX()&&_objs[i].getPosY()==(_fish.getPosY()+1)){
            this->_objs.erase(_objs.begin()+i);//to check
            continue;
        }
        if((!_objs[i].canCover())
                &&(_objs[i].getPosX()+_objs[i].getWidth()-1)>=_fish.getPosX()&&_objs[i].getPosX()<=_fish.getPosX()
                &&(_objs[i].getPosY()+_objs[i].getHeight()-1)>=(_fish.getPosY()+1)&&_objs[i].getPosY()<=(_fish.getPosY()+1)){
            this->_fish.move(oppo, steps);
            continue;
        }
        if(_fish.getPosY()>19||_fish.getPosY()<7||_fish.getPosX()<6||_fish.getPosX()>34){//x:6~29 y:8~19
            this->_fish.move(oppo, steps);
            continue;
        }

    }
}

double World::getPlayerX()
{
    return _player.getPosX();
}

double World::getPlayerY()
{
    return _player.getPosY();
}

void World::save(string mapFile){//to change
    ofstream fout(mapFile);
    fout<<"player "<<_player.getPosX()<<" "<<_player.getPosY()<<endl;
    int all=_objs.size();
    for(int i=0;i<all;i++){
        fout<<_objs[i].getObjType()<<" "<<_objs[i].getPosX()<<" "<<_objs[i].getPosY()<<endl;
    }

}
