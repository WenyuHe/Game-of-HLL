#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "fish.h"

class World
{
public:
    World();
    ~World(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    void handleFishMove(int direction, int steps);

    double getPlayerX();
    double getPlayerY();
        //假定只有一个玩家
    void save(string mapFile);

    void changeFish();
    int getFishCount();
    void putFish();

private:
    int game3,fishPut;
    vector<RPGObj> _objs;
    Player _player;
    Fish _fish;
    QImage _map,fishBasket;

};

#endif // WORLD_H
