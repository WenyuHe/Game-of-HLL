#include "world_br.h"
#include"iostream"
#include "icon_br.h"
#include"rpgobj_br.h"
using namespace std;

bool World_br::has_eaten = false;

void World_br::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5
    this->_player.initObj("player");
    this->_player.setPosX(7);
    this->_player.setPosY(9);

    this->_pig1.initObj("pig1");
    this->_pig1.setPosX(5);
    this->_pig1.setPosY(6);

    this->_pig2.initObj("pig2");
    this->_pig2.setPosX(8);
    this->_pig2.setPosY(6);

    this->_pig3.initObj("pig3");
    this->_pig3.setPosX(5);
    this->_pig3.setPosY(9);

    RPGObj_br O_init;
    //----------四个角--------------
    O_init.placeObject_h("shelf", 6, 0, 0, &_objs);
    O_init.placeObject_h("frige", 6, 0, 1, &_objs);
    O_init.placeObject_h("shelf", 6, 0, 2, &_objs);
    O_init.placeObject_h("frige", 6, 0, 3, &_objs);
    O_init.placeObject_h("shelf", 6, 0, 4, &_objs);

    O_init.placeObject_v("frige", 5, 0, 13, &_objs);
    O_init.placeObject_v("chair", 5, 1, 13, &_objs);
    O_init.placeObject_v("frige", 5, 2, 13, &_objs);
    O_init.placeObject_v("desk", 5, 3, 13, &_objs);
    O_init.placeObject_v("frige",5, 4, 13, &_objs);

    O_init.placeObject_h("desk", 5, 22, 0, &_objs);
    O_init.placeObject_h("chair", 5, 22, 1, &_objs);
    O_init.placeObject_h("shelf", 5, 22, 2, &_objs);
    O_init.placeObject_h("sofa", 5, 22, 3, &_objs);
    O_init.placeObject_h("shelf", 5, 22, 4, &_objs);

    O_init.placeObject_v("shelf", 5, 22, 13, &_objs);
    O_init.placeObject_v("chair", 5, 23, 13, &_objs);
    O_init.placeObject_v("frige", 5, 24, 13, &_objs);
    O_init.placeObject_v("desk", 5, 25, 13, &_objs);
    O_init.placeObject_v("frige",5, 26, 13, &_objs);

    //------------------中间一大块----------------------

    O_init.placeObject_v("desk",2, 8, 3, &_objs);
    O_init.placeObject_v("frige",1, 8, 5, &_objs);
    O_init.placeObject_v("chair",4, 8, 6, &_objs);
    O_init.placeObject_v("frige",3, 8, 10, &_objs);
    O_init.placeObject_v("shelf",2, 8, 13, &_objs);

    O_init.placeObject_h("chair", 1, 9, 14, &_objs);
    O_init.placeObject_h("desk", 3, 10, 14, &_objs);
    O_init.placeObject_h("sofa", 2, 13, 14, &_objs);
    O_init.placeObject_h("shelf", 1, 15, 14, &_objs);
    O_init.placeObject_h("chair", 2, 16, 14, &_objs);

    O_init.placeObject_v("chair",1, 18, 3, &_objs);
    O_init.placeObject_v("sofa",2, 18, 4, &_objs);
    O_init.placeObject_v("chair",2, 18, 6, &_objs);
    O_init.placeObject_v("desk",2, 18, 8, &_objs);
    O_init.placeObject_v("frige",2, 18, 10, &_objs);
    O_init.placeObject_v("shelf",3, 18, 12, &_objs);

    O_init.placeObject_h("frige", 1, 9, 3, &_objs);
    O_init.placeObject_h("sofa", 3, 10, 3, &_objs);
    O_init.placeObject_h("desk", 2, 13, 3, &_objs);
    O_init.placeObject_h("shelf", 1, 15, 3, &_objs);
    O_init.placeObject_h("chair", 2, 16, 3, &_objs);

//----------8<x<18-------3<y<14--------------
    //----------中间框内第一列-------------------
    O_init.placeObject_v("frige",3, 9, 4, &_objs);
    O_init.placeObject_v("chair",1, 9, 7, &_objs);
    O_init.placeObject_v("desk",2, 9, 8, &_objs);
    O_init.placeObject_v("sofa",1, 9, 11, &_objs);
    O_init.placeObject_v("desk",2, 9, 12, &_objs);
    //------------------中间框内第二列-------------------
    O_init.placeObject_v("sofa",1, 10, 5, &_objs);
    O_init.placeObject_v("frige",3, 10, 6, &_objs);
    O_init.placeObject_v("desk",2, 10, 10, &_objs);
    O_init.placeObject_v("shelf",1, 10, 12, &_objs);
    O_init.placeObject_v("chair",1, 10, 13, &_objs);
    //---------中间框内第三列----------------------
    O_init.placeObject_v("frige",1, 11, 5, &_objs);
    O_init.placeObject_v("desk", 3, 11, 8, &_objs);
    O_init.placeObject_v("chair",2, 11, 12, &_objs);
    //--------中间框内第四列---------------------
    O_init.placeObject_v("sofa",3, 12, 5, &_objs);
    O_init.placeObject_v("frige",2, 12, 8, &_objs);
    O_init.placeObject_v("chair",2, 12, 10, &_objs);
    //--------中间框内第四列--------------
    O_init.placeObject_v("desk",1, 13, 5, &_objs);
    O_init.placeObject_v("chair",2, 13, 6, &_objs);
    O_init.placeObject_v("desk",1, 13, 8, &_objs);
    O_init.placeObject_v("frige",3, 13, 11, &_objs);
    //---------中间框内第五列---------------
    O_init.placeObject_v("sofa",2, 14, 4, &_objs);
    O_init.placeObject_v("desk",1, 14, 7, &_objs);
    O_init.placeObject_v("frige",3, 14, 9, &_objs);
    O_init.placeObject_v("chair",2, 14, 12, &_objs);
    //---------中间框内第六列-------------------
    O_init.placeObject_v("desk",2, 15, 4, &_objs);
    O_init.placeObject_v("frige",1, 15, 8, &_objs);
    O_init.placeObject_v("chair",3, 15, 9, &_objs);
    O_init.placeObject_v("sofa",1, 15, 12, &_objs);
    O_init.placeObject_v("frige",1, 15, 13, &_objs);
    //-------------中间框内第七列-----------------------
    O_init.placeObject_v("frige", 3, 16, 4, &_objs);
    O_init.placeObject_v("sofa", 1, 16, 9, &_objs);
    O_init.placeObject_v("frige",2, 16, 10, &_objs);
    O_init.placeObject_v("desk",2, 16, 12, &_objs);
    //------------中间框内第八列-----------------------
    O_init.placeObject_v("chair",1, 17, 4, &_objs);
    O_init.placeObject_v("shelf",4, 17, 6, &_objs);
    O_init.placeObject_v("desk",2, 17, 10, &_objs);
    O_init.placeObject_v("frige",1, 17, 12, &_objs);
    O_init.placeObject_v("chair",1, 17, 13, &_objs);

    //----------其他

}


void World_br::show(QPainter * painter){
    vector<RPGObj_br>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
    /*this->_pig1.show(painter);
    this->_pig2.show(painter);
    this->_pig3.show(painter);*/
    this->_player.show(painter);
}

void World_br::handlePlayerMove(int direction, int steps){
    switch (direction){
        case 1://up
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == -1){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 - 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }
        }

           this->_player.move(direction, steps);
            break;

        case 2://down
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == 16){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 + 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
        this->_player.move(direction, steps);
            break;
        case 3://left
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 0){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1 == _objs[i].getPosY() && this->_player.getPosX() - 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
           this->_player.move(direction, steps);
            break;
        case 4://right
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 26){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1== _objs[i].getPosY() && this->_player.getPosX() + 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }

            }

        }
            this->_player.move(direction, steps);
            break;
        case 5:
            this->_player.move(direction, steps);
            break;
   // this->_player.move(direction, steps);
   }
}

int World_br::getobjX(int i){
    return _objs[i].getPosX();
}

int World_br::getobjY(int i){
    return _objs[i].getPosY();
}

bool World_br::getCanCover(int i){
    return _objs[i].canCover();
}

bool World_br::getCanEat(int i){
    return _objs[i].canEat();
}
