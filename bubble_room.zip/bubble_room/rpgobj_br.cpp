#include "rpgobj_br.h"
#include <iostream>

void RPGObj_br::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if (type.compare("player")==0){
        this->_coverable = true;
        this->_bombable = true;
        this->_eatable = false;
    }
    else if (type.compare("pig1")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("pig2")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("pig3")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("sofa")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }

    else if (type.compare("chair")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("frige")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("bomb")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("blast_h")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("blast_v")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("cake")==0){
        this->_coverable = true;
        this->_bombable = false;
         this->_eatable = true;
    }
    else if (type.compare("desk")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("shelf")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else{
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON_br::findICON(type);
    QImage all;
    all.load("N:\\material1.png");
    this->_pic = all.copy(QRect(_icon.getScrX()*ICON_br::GRID_SIZE_SET, _icon.getScrY()*ICON_br::GRID_SIZE_SET, _icon.getWidth()*ICON_br::GRID_SIZE_SET, _icon.getHeight()*ICON_br::GRID_SIZE_SET));
}

void RPGObj_br::show(QPainter * pa){
    int gSize = ICON_br::GRID_SIZE_SET;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}


/*bool RPGObj_br::getisEaten(int i){
    return _is_eaten;
}*/

void RPGObj_br::placeObject_v(string obj, int length, int posX, int posY, vector<RPGObj_br> *_objs){
    if (obj.compare("sofa")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj("sofa");
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            (*_objs).push_back(_obj);
            posY++;
        }
    }

    else if (obj.compare("chair")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj("chair");
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            (*_objs).push_back(_obj);
            posY++;
        }
    }
    else if (obj.compare("frige")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj("frige");
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            (*_objs).push_back(_obj);
            posY++;
        }
    }
    else if (obj.compare("desk")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj("desk");
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            (*_objs).push_back(_obj);
            posY++;
        }
    }
    else if (obj.compare("shelf")==0){
        for(int i = 0; i < length; i++){
            RPGObj_br _obj;
            _obj.initObj("shelf");
            _obj.setPosX(posX);
            _obj.setPosY(posY);
            (*_objs).push_back(_obj);
            posY++;
        }
    }
}

void RPGObj_br::placeObject_h(string obj, int length, int posX, int posY, vector<RPGObj_br> *_objs){
        if (obj.compare("sofa")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj("sofa");
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                (*_objs).push_back(_obj);
                posX++;
            }
        }

        else if (obj.compare("chair")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj("chair");
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                (*_objs).push_back(_obj);
                posX++;
            }
        }
        else if (obj.compare("frige")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj("frige");
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                (*_objs).push_back(_obj);
                posX++;
            }
        }
        else if (obj.compare("desk")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj("desk");
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                (*_objs).push_back(_obj);
                posX++;
            }
        }
        else if (obj.compare("shelf")==0){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj("shelf");
                _obj.setPosX(posX);
                _obj.setPosY(posY);
                (*_objs).push_back(_obj);
                posX++;
            }
    }
}
