#ifndef ICON_BR_H
#define ICON_BR_H

#include<string>
#include<map>
using namespace std;


//将一类图标定位到素材图片上的具体区域
class ICON_br{
public:
    static int GRID_SIZE_SET;//游戏中一格，相当于图片中多少像素
    static map<string,ICON_br> GAME_ICON_SET;
     //确定各类物体子素材图片的位置，高、宽等数据
    static ICON_br findICON(string type);
      //根据物体类型名找到图标
    ICON_br(){}
    ICON_br(string name, int x, int y, int w, int h);
    string getTypeName() const{return this->typeName;}
    int getScrX() const{return this->ScrX;}
    int getScrY() const{return this->ScrY;}
    int getWidth() const{return this->width;}
    int getHeight() const{return this->height;}

private:
    string typeName;
    int ScrX, ScrY, width, height;
};

#endif // ICON_BR_H
