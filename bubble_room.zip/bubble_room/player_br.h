#ifndef PLAYER_BR_H
#define PLAYER_BR_H
#include "rpgobj_br.h"
class Player_br: public RPGObj_br
{
public:
    Player_br(){}
    ~Player_br(){}
    void move(int direction, int steps=1);
        //direction =1,2,3,4 for 上下左右
};


#endif // PLAYER_BR_H
