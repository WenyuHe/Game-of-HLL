#ifndef WORLD_BR_H
#define WORLD_BR_H
#include "rpgobj_br.h"
#include <vector>
#include <string>
#include <QPainter>
#include<QLabel>
#include "player_br.h"

class World_br
{
public:
    World_br(){}
    ~World_br(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    void pigMove();
    int getobjX(int i);
    int getobjY(int i);
    bool getCanCover(int i);
    bool getCanBomb(int i);
    bool getCanEat(int i);
    static bool has_eaten;
    //int get_has_eaten() const;
    //int getghostposX();
    //int getghostposY();

        //假定只有一个玩家

private:
   vector<RPGObj_br>_objs;
    Player_br _player;
    Player_br _pig1;
    Player_br _pig2;
    Player_br _pig3;

};

#endif // WORLD_BR_H
