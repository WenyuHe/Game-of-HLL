#include "world_br.h"
#include"iostream"
#include "Icon.h"
#include"rpgobj_br.h"
#include"object_br.h"
#include <QTimer>
#include<QTime>
#include"mainwindow.h"
#include<QPainter>
#include <QMediaPlayer>
#include<fstream>


using namespace std;

bool World_br::has_eaten = false;

//改---------------------
void World_br::placeObject(string mapFile){
    //读入一行 1.判读是h还是v 2.判读object的type 3.放置的个数 4.放置的坐标
    ifstream fin(mapFile);
    string direction,type;
    int length,Pos_x,Pos_y;
    while(!fin.eof()){
        fin>>direction>>type>>length>>Pos_x>>Pos_y;
        if(direction=="h"){
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj(type);
                _obj.setPosX(Pos_x);
                _obj.setPosY(Pos_y);
                _objs.push_back(_obj);
                Pos_x++;
            }
        }

        else{
            for(int i = 0; i < length; i++){
                RPGObj_br _obj;
                _obj.initObj(type);
                _obj.setPosX(Pos_x);
                _obj.setPosY(Pos_y);
                _objs.push_back(_obj);
                Pos_y++;
            }
        }
    }
}
void World_br::resetGame1(string mapFile){
    this->_player.initObj("player_br");
    this->_player.setPosX(12);
    this->_player.setPosY(11);
    this->_player.setDead(0);

    _pigs.clear();


    Player_br pig;
    pig.initObj("pig1_br");
    pig.setPosX(9);
    pig.setPosY(13);
    _pigs.push_back(pig);

    pig.initObj("pig2_br");
    pig.setPosX(16);
    pig.setPosY(4);
    _pigs.push_back(pig);

    pig.initObj("pig1_br");
    pig.setPosX(26);
    pig.setPosY(17);
    _pigs.push_back(pig);

    placeObject(mapFile);
//--------------------音乐-------------
     _BGM.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\pig_BGM.mp3"));
     _BGM.setVolume(80);

     _win.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\win.mp3"));
     _win.setVolume(100);

     _lose.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\lose.mp3"));
     _lose.setVolume(100);

     _placebomb.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\placeBomb.mp3"));
     _placebomb.setVolume(100);

     _explode.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\explode.mp3"));
     _explode.setVolume(100);

     _pigdead.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\pigDead.mp3"));
     _pigdead.setVolume(800);
//---------------背景-----------------
     QImage background;
     background.load("C:\\mole\\floor0.jpg");
     _background = background.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE,24*Icon::GRID_SIZE));
//------------winning&losing-------------------
     QImage win;
     win.load("C:\\mole\\win.jpg");
     _Win = win.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 11*Icon::GRID_SIZE,11*Icon::GRID_SIZE));
     QImage lose;
     lose.load("C:\\mole\\game over.jpg");
     _Lose = lose.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 12*Icon::GRID_SIZE,12*Icon::GRID_SIZE));

}
void World_br::initWorld(string mapFile){
    this->_player.initObj("player_br");
    this->_player.setPosX(12);
    this->_player.setPosY(11);

    Player_br pig;
    pig.initObj("pig1_br");
    pig.setPosX(9);
    pig.setPosY(13);
    _pigs.push_back(pig);

    pig.initObj("pig2_br");
    pig.setPosX(16);
    pig.setPosY(4);
    _pigs.push_back(pig);

    pig.initObj("pig1_br");
    pig.setPosX(26);
    pig.setPosY(17);
    _pigs.push_back(pig);

    placeObject(mapFile);
//--------------------音乐-------------
     _BGM.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\pig_BGM.mp3"));
     _BGM.setVolume(80);

     _win.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\win.mp3"));
     _win.setVolume(100);

     _lose.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\lose.mp3"));
     _lose.setVolume(100);

     _placebomb.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\placeBomb.mp3"));
     _placebomb.setVolume(100);

     _explode.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\explode.mp3"));
     _explode.setVolume(100);

     _pigdead.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\pigDead.mp3"));
     _pigdead.setVolume(800);
//---------------背景-----------------
     QImage background;
     background.load("C:\\mole\\floor0.jpg");
     _background = background.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE,24*Icon::GRID_SIZE));
//------------winning&losing-------------------
     QImage win;
     win.load("C:\\mole\\win.jpg");
     _Win = win.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 11*Icon::GRID_SIZE,11*Icon::GRID_SIZE));
     QImage lose;
     lose.load("C:\\mole\\game over.jpg");
     _Lose = lose.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 12*Icon::GRID_SIZE,12*Icon::GRID_SIZE));

}

bool World_br::playerBombPlayer(){
    if((_player.getPosX()>=_player.getBomb().getPosX()-1 && _player.getPosX() <= _player.getBomb().getPosX()+1 && _player.getPosY() + 1 == _player.getBomb().getPosY())
            ||(_player.getPosY() + 1 >=_player.getBomb().getPosY()-1 && _player.getPosY()+1 <= _player.getBomb().getPosY()+1 && _player.getPosX() == _player.getBomb().getPosX()))
       return 1;
    else return 0;
}

bool World_br::playerBeBombedBy(Player_br p){
        if((_player.getPosX()>=p.getBomb().getPosX()-1
            && _player.getPosX() <= p.getBomb().getPosX()+1
            && _player.getPosY() + 1 == p.getBomb().getPosY())
                || (_player.getPosY() + 1 >= p.getBomb().getPosY() - 1
            && _player.getPosY()  + 1 <= p.getBomb().getPosY()+1
            && _player.getPosX() == p.getBomb().getPosX()))
           return 1;

         else return 0;
}

bool World_br::pigBeBombed(Player_br p){
    if((p.getPosX()>=_player.getBomb().getPosX()-1 && p.getPosX() <= _player.getBomb().getPosX()+1 && p.getPosY() + 1 == _player.getBomb().getPosY())
            ||(p.getPosY() + 1 >=_player.getBomb().getPosY()-1 && p.getPosY()+1 <= _player.getBomb().getPosY()+1 && p.getPosX() == _player.getBomb().getPosX()))
       return 1;
    else return 0;
}


//解决炸弹重置问题，不然就算已经爆炸完毕走到原地依旧会死
void World_br::show(QPainter * painter){
    static int l_p = 0, w_p = 0;
    if(_player.getIsDead() == 1) {
        _BGM.stop();
        painter->drawImage(700, 300, this->_Lose);
        if(l_p == 1) return;
        _lose.play();
        l_p = 1;
        return;//游戏结束
    }
   if(_pigs.size() == 0) {
       _BGM.stop();
        painter->drawImage(700, 300, this->_Win);
        if(w_p == 1) return;
        _win.play();
        w_p = 1;
       return;
   }
    //以下先画背景
  painter->drawImage(0,0,this->_background);
    //------p弹-layer的炸--------------
    if(MainWindow::count_scs - _player.getPlacetime() <= 2 ){
        _player.getBomb().show(painter);
    }
    if(MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4){
        _explode.play();
        for(int i = 0; i < _objs.size(); i++){
            if((_objs[i].getPosX()>=_player.getBomb().getPosX()-1 && _objs[i].getPosX() <= _player.getBomb().getPosX()+1 && _objs[i].getPosY() == _player.getBomb().getPosY())
                    || (_objs[i].getPosY() >= _player.getBomb().getPosY() - 1 && _objs[i].getPosY() <= _player.getBomb().getPosY()+1 && _objs[i].getPosX() == _player.getBomb().getPosX())){
                if(_objs[i].canBomb() == 1){
                    _objs.erase(_objs.begin()+i);
                }
            }
        }
        _player.getBlast_h().show(painter);
        _player.getBlast_v().show(painter);
        _player.setHasSetBomb(0);
        if(playerBombPlayer() == 1
                && (MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4)){
            //游戏结束—-player炸player
            _player.setDead(1);
            _lose.play();
        }
        for(int t = 0; t < _pigs.size(); t++){//player 炸pig
            if(pigBeBombed(_pigs[t]) == 1 && (MainWindow::count_scs - _player.getPlacetime() >2 && MainWindow::count_scs - _player.getPlacetime() <= 4)){
                _pigdead.play();
                _pigs[t].setDead(1);
                _pigs.erase(_pigs.begin()+t);
            }
        }
    }
    //---------pig的炸弹------------------
    for(int t = 0; t <_pigs.size(); t++){
        if(MainWindow::count_scs - _pigs[t].getPlacetime() <= 2 ){
            _pigs[t].getBomb().show(painter);
        }
        if(MainWindow::count_scs - _pigs[t].getPlacetime() >2 && MainWindow::count_scs - _pigs[t].getPlacetime() <= 4){
            _explode.play();
            for(int i = 0; i < _objs.size(); i++){
                if(_objs[i].getPosX()>=_pigs[t].getBomb().getPosX()-1 && _objs[i].getPosX() <= _pigs[t].getBomb().getPosX()+1 && _objs[i].getPosY() == _pigs[t].getBomb().getPosY()
                        || _objs[i].getPosY() >= _pigs[t].getBomb().getPosY() - 1 && _objs[i].getPosY() <= _pigs[t].getBomb(). getPosY()+1 && _objs[i].getPosX() == _pigs[t].getBomb().getPosX()){
                    if(_objs[i].canBomb() == 1){
                        _objs.erase(_objs.begin()+i);
                    }
                }
            }
            _pigs[t].getBlast_h().show(painter);
            _pigs[t].getBlast_v().show(painter);
            _pigs[t].setHasSetBomb(0);
            if(playerBeBombedBy(_pigs[t]) == 1
                    && (MainWindow::count_scs - _pigs[t].getPlacetime() >2 && MainWindow::count_scs - _pigs[t].getPlacetime() <= 4)){
                //游戏结束  pig炸player
                _player.setDead(1);
                _lose.play();
            }
        }
   }

    for(int i = 0; i < _objs.size(); i++){
            _objs[i].show(painter);
    }
    for(int t = 0; t < _pigs.size(); t++){
            _pigs[t].show(painter);
    }

    if(_player.getIsDead() == 1) {
        _player.show(painter);
        return;//游戏结束
    }
    this->_player.show(painter);

}


void World_br::handlePlayerMove(int direction, int steps){
    switch (direction){
        case 1://up
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == 2){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 - 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }
        }

           this->_player.move(direction, steps);
            break;

        case 2://down
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosY() == 19){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY()+ 1 + 1 == _objs[i].getPosY() && this->_player.getPosX() == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
        this->_player.move(direction, steps);
            break;
        case 3://left
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 5){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1 == _objs[i].getPosY() && this->_player.getPosX() - 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }
            }

        }
           this->_player.move(direction, steps);
            break;
        case 4://right
        for(int i = 0; i < _objs.size(); i++){
            if(_player.getPosX() == 31){
                this->_player.move(5, steps);
                return;
            }
            if(this->_player.getPosY() + 1== _objs[i].getPosY() && this->_player.getPosX() + 1 == _objs[i].getPosX()){
                if(_objs[i].canCover() == 0 && _objs[i].canEat() == 0){
                    this->_player.move(5, steps);
                    return;
                }
                else if(_objs[i].canCover() == 0 && _objs[i].canEat() == 1){
                    _objs[i].changeisEaten();
                    this->_player.move(direction, steps);
                    has_eaten = true;
                    return;
                }

            }

        }
            this->_player.move(direction, steps);
            break;
        case 5:
            this->_player.move(direction, steps);
            break;
   }
}


void World_br::pigMove(){
    int dir;
    for(int t = 0; t < _pigs.size(); t++){
        if(_pigs[t].getplayerHasSet() == 1) continue;
    //在这里是一段判断自己身边的位置是否是空的代码
        bool te = 1, be = 1, le = 1, re = 1;
        for(int i = 0; i < _objs.size(); i++){
            if((_pigs[t].getPosX() + 1 == _objs[i].getPosX()
                && _pigs[t].getPosY()+1 == _objs[i].getPosY())
              || _pigs[t].getPosX()+1 == 26){
                re = 0;
            }
            if((_pigs[t].getPosX() - 1 == _objs[i].getPosX()
                && _pigs[t].getPosY() + 1 == _objs[i].getPosY() )
              || _pigs[t].getPosX()-1 == -1){
                le = 0;
            }
            if((_pigs[t].getPosY()  == _objs[i].getPosY()
                &&_pigs[t].getPosX() == _objs[i].getPosX() )
              || _pigs[t].getPosY()-1 == -2){
                te = 0;
            }
            if((_pigs[t].getPosY() + 2 == _objs[i].getPosY()
                && _pigs[t].getPosX() == _objs[i].getPosX())
              || _pigs[t].getPosY()+2 == 18){
                be = 0;
            }
        }
    //----------先判断上下位置-----------------
        int has_moved  = 0, rd = 0;
        if(_player.getPosY()<_pigs[t].getPosY() && te == 1){
            dir = 1;
            has_moved = 1;
        }
        else if(_player.getPosY()>_pigs[t].getPosY() && be == 1){
            dir = 2;
            has_moved = 1;
        }
        else{
             dir = 5;
             rd++;
        }
        _pigs[t].move(dir,1);
        if(has_moved == 1) return;
    //---------------再判断左右位置-----------------//拐弯处再作修改

        if(_player.getPosX()<_pigs[t].getPosX() && le == 1){
            dir = 3;

          }
        else if(_player.getPosX()>_pigs[t].getPosX() && re == 1){
            dir = 4;

        }
        else{
            dir = 5;
            rd++;
        }
       _pigs[t].move(dir,1);

     //-------------放置炸弹--------------------
        if(rd == 2){
            _pigs[t].placeBomb();
            _placebomb.play();
            _pigs[t].setHasSetBomb(1);

        }
    }
}


int World_br::getobjX(int i){
    return _objs[i].getPosX();
}

int World_br::getobjY(int i){
    return _objs[i].getPosY();
}

bool World_br::getCanCover(int i){
    return _objs[i].canCover();
}

bool World_br::getCanEat(int i){
    return _objs[i].canEat();
}


