#include "world3.h"
#include "icon.h"
#include <fstream>
#include <string>
#include <QMediaPlayer>
World3::World3():fishPut(0),memeChange(0),candyCount(0){}

void World3::initWorld3(string mapFile){
    //读入地图文件，生成地图上的对象
    ifstream fin(mapFile);
    string type;
    RPGObj obj;
    int x=0,y=0;
    while(!fin.eof()){
        fin>>type>>x>>y;
        if(type=="player"){
            this->_player.initObj("player");
            this->_player.setPosX(25);
            this->_player.setPosY(10);
        }else if(type=="candy"||type=="basket"||type=="meme"){
            obj.initObj(type);
            obj.setPosX(x);
            obj.setPosY(y);
            this->_objs.push_back(obj);
        }else if(type=="balloon"){
            this->_balloon.initObj(type);
            this->_balloon.setPosX(x);
            this->_balloon.setPosY(y);
        }else if(type=="fish"){
            this->_fish.initObj(type);
            this->_fish.setPosX(x);
            this->_fish.setPosY(y);
        }else if(type=="pig1"||type=="pig2"||type=="pig3"||type=="pig4"){
            obj.initObj(type);
            obj.setPosX(x);
            obj.setPosY(y);
            this->_pig.push_back(obj);
        }
    }
    fin.close();
    QImage map,all,dialogue1, dialogue2,dialogue3;
    map.load("C:\\mole\\street.png");
    _map = map.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE, 24*Icon::GRID_SIZE));
    all.load("C:\\mole\\all.png");
    fishBasket = all.copy(QRect(2*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 1*Icon::GRID_SIZE, 1*Icon::GRID_SIZE));

    dialogue1.load("C:\\mole\\dialg1.png");
    _dialg1 = dialogue1.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE, 24*Icon::GRID_SIZE));
    dialogue2.load("C:\\mole\\dialg2.png");
    _dialg2 = dialogue2.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE, 24*Icon::GRID_SIZE));
    dialogue3.load("C:\\mole\\dialg3.png");
    _dialg3 = dialogue3.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 36*Icon::GRID_SIZE, 24*Icon::GRID_SIZE));

    _BGM.setMedia(QUrl::fromLocalFile("C:\\mole\\music_material\\street.mp3"));
    _BGM.setVolume(80);
    this->playBGM();
}
//-------------------fishing begin------------------
void World3::changeFish(){
    _fish.changefishCount();
}

int World3::getFishCount(){
    return _fish.getfishCount();
}

void World3::putFish()
{
    if(this->getPlayerX()!=32||this->getPlayerY()!=14
            ||this->_fish.getPosX()!=32||this->_fish.getPosY()!=15){
        return;//change with basket place in map.txt
    }
    fishPut=1;
    this->_pig.erase(_pig.begin());
}
//--------------------fishing end---------------------
void World3::show(QPainter * painter){
    painter->drawImage(0,0,this->_map);
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
    for(it=this->_pig.begin();it!=this->_pig.end();it++){
        (*it).show(painter);
    }

    if(fnsh_rding_rule == 0)
        painter->drawImage(0,570,this->_dialg1);
    if(fnsh_rding_rule == 1)
        painter->drawImage(0,570,this->_dialg2);
    if(fnsh_rding_rule == 2)
        painter->drawImage(0,570,this->_dialg3);

    if(fishPut){//change with basket place in map.txt
        painter->drawImage(32*Icon::GRID_SIZE,15*Icon::GRID_SIZE,this->fishBasket);
    }
    this->_player.show(painter);
    if(fishPut==0){
        this->_fish.show(painter);
    }
    this->_balloon.show(painter);
}

void World3::handlePlayerMove(int direction, int steps){
    if(fnsh_rding_rule != 3) return;

    this->_player.move(direction, steps);
    int all=_objs.size(),oppo=(direction-2>0)?direction-2:direction+2;
    for(int i=0;i<all;i++){
        if(_objs[i].canEat()&&_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==(_player.getPosY()+1)){
            this->_objs.erase(_objs.begin()+i);//to check
            candyCount++;//目前只有糖果可吃，不必判断
            continue;
        }
        if((!_objs[i].canCover())
                &&(_objs[i].getPosX()+_objs[i].getWidth()-1)>=_player.getPosX()&&_objs[i].getPosX()<=_player.getPosX()
                &&(_objs[i].getPosY()+_objs[i].getHeight()-1)>=(_player.getPosY()+1)&&_objs[i].getPosY()<=(_player.getPosY()+1)){
            this->_player.move(oppo, steps);
            continue;
        }
        if(_player.getPosY()>17||_player.getPosY()<10||_player.getPosX()<6||_player.getPosX()>34){//x:6~29 y:8~19
            this->_player.move(oppo, steps);
            continue;
        }

    }
}

void World3::playBGM(){
    _BGM.play();
}


void World3::stopBGM(){
    _BGM.stop();
}

void World3::handleFishMove(int direction, int steps)
{
    this->_fish.move(direction, steps);
    int all=_objs.size(),oppo=(direction-2>0)?direction-2:direction+2;
    for(int i=0;i<all;i++){
        if((!_objs[i].canCover())
                &&(_objs[i].getPosX()+_objs[i].getWidth()-1)>=_fish.getPosX()&&_objs[i].getPosX()<=_fish.getPosX()
                &&(_objs[i].getPosY()+_objs[i].getHeight()-1)>=(_fish.getPosY()+1)&&_objs[i].getPosY()<=(_fish.getPosY()+1)){
            this->_fish.move(oppo, steps);
            continue;
        }
        if(_fish.getPosY()>18||_fish.getPosY()<11||_fish.getPosX()<6||_fish.getPosX()>34){//x:6~29 y:8~19
            this->_fish.move(oppo, steps);
            continue;
        }

    }
}

void World3::memeTalk(QWidget *mw)
{
    if(this->getPlayerX()!=16||this->getPlayerY()!=10){
        return;
    }
    QMessageBox me;
    if(memeChange==2){
            me.about(mw,"么么公主","去钓鱼怎么样^-^");
        }else if(memeChange==0){
            me.about(mw,"么么公主","去宠物店看看吧^-^");
        }else if(memeChange==1){
            me.about(mw,"么么公主","去旁边的服装店看看吧^-^");
        }else if(memeChange==3){
            me.about(mw,"么么公主","糖里有惊喜噢~^-^");
        }

}

void World3::setmemeChange(int m)
{
    memeChange=m;
}

bool World3::balloonMove()
{
    if(_balloon.getPosY()<-12){//移动到尽头
        return false;
    }
    _balloon.move(1,1);
    return true;
}

void World3::setCandyCount(int cc)
{
    candyCount=cc;
}

int World3::getCandyCount()
{
    return candyCount;
}

void World3::putawayPig()
{
    this->_pig.erase(_pig.begin());
}

double World3::getPlayerX()
{
    return _player.getPosX();
}

double World3::getPlayerY()
{
    return _player.getPosY();
}

void World3::save(string mapFile){//to change
    ofstream fout(mapFile);
    fout<<"player "<<_player.getPosX()<<" "<<_player.getPosY()<<endl;
    int all=_objs.size();
    for(int i=0;i<all;i++){
        fout<<_objs[i].getObjType()<<" "<<_objs[i].getPosX()<<" "<<_objs[i].getPosY()<<endl;
    }
    all=_pig.size();
    for(int i=0;i<all;i++){
        fout<<_pig[i].getObjType()<<" "<<_pig[i].getPosX()<<" "<<_pig[i].getPosY()<<endl;
    }
    fout<<"fish "<<_fish.getPosX()<<" "<<_fish.getPosY()<<endl;
    fout<<"balloon "<<_balloon.getPosX()<<" "<<_balloon.getPosY()<<endl;
}
