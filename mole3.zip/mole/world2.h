#ifndef World2_H
#define World2_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "mole.h"
#include "ghost.h"
#include "blood.h"
#include <QMediaPlayer>
class World2
{
public:
    World2(){}
    ~World2(){}
    void initWorld2(string mapFile);//输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪

    void show(QPainter * painter);//显示游戏世界所有对象
    bool handleFireMove();//为啥要bool
    bool handleWaterMove();
    bool handleIndianMove();
    void ghost2fire();//产生火焰
    void mole2water();//产生水
    void mole2indian();//产生印第安人
    void playBGM(){
                    _Musicplayer.setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\darkforest.mp3"));
                    _Musicplayer.setVolume(20);
                    _Musicplayer.play();}
    void stopBGM(){
        _Musicplayer.stop();
    }
private:
    vector<Weapon> _fire;
    vector<Weapon> _water;
    vector<Weapon> _indian;
    Mole _mole;
    Ghost _ghost;
    Blood _moleblood,_ghostblood;
    bool moledead,ghostdead;
    QImage _map;
    QMediaPlayer _Musicplayer;
};

#endif // World2_H
