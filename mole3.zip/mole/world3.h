#ifndef WORLD3_H
#define WORLD3_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "fish.h"
#include <QMessageBox>
#include <QMediaPlayer>
class QWidget;
class World3
{
public:
    World3();
    ~World3(){}
    void initWorld3(string mapFile);
    void show(QPainter * painter);//显示游戏世界所有对象
    void save(string mapFile);

    double getPlayerX();
    double getPlayerY();//假定只有一个玩家
    void handlePlayerMove(int direction, int steps);

    void playBGM();
    void stopBGM();

    void changeFish();
    int getFishCount();
    void putFish();
    void handleFishMove(int direction, int steps);

    void memeTalk(QWidget * mw);
    void setmemeChange(int m);
    bool balloonMove();
    void setCandyCount(int cc);
    int getCandyCount();
    void putawayPig();
    int fnshOneDialg(){this->fnsh_rding_rule++;}
    int getFnsh_rding_rule(){return this->fnsh_rding_rule;}
private:
    int fishPut,memeChange,candyCount,fnsh_rding_rule = 0;
    vector<RPGObj> _objs;
    vector<RPGObj> _pig;
    RPGObj _balloon;
    Player _player;
    Fish _fish;
    QImage _map,fishBasket, _dialg1, _dialg2, _dialg3;
    QMediaPlayer _BGM;

};

#endif // WORLD3_H
