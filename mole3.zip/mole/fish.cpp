#include "fish.h"

Fish::Fish():
    fishCount(0)
{
    QImage fish;
    fish.load(("C:\\mole\\fishing.png"));
    _fish[0] = fish.copy(QRect(0*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 3*Icon::GRID_SIZE, 3*Icon::GRID_SIZE));
    _fish[1] = fish.copy(QRect(3*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 3*Icon::GRID_SIZE, 3*Icon::GRID_SIZE));
    _fish[2] = fish.copy(QRect(6*Icon::GRID_SIZE, 0*Icon::GRID_SIZE, 3*Icon::GRID_SIZE, 3*Icon::GRID_SIZE));

}

void Fish::show(QPainter * painter){
    int gSize = Icon::GRID_SIZE;
    if(fishCount>0&&fishCount<4){
        painter->drawImage(9*gSize,17*gSize,this->_fish[fishCount-1]);

    }
    if(fishCount==4){//钓完鱼，显示鱼被抱着
        RPGObj::show(painter);
    }

}

void Fish::changefishCount(){
    this->fishCount++;
}

int Fish::getfishCount(){
    return fishCount;
}
