#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "icon.h"
#include <QTimer>
#include <map>
#include <iostream>
#include <fstream>
#include<string>
using namespace std;

int MainWindow::count_scs=0;
int MainWindow::seconds=0;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    now(3),game1(0),game2(0),game3(0),
    ui(new Ui::MainWindow)

{
    ui->setupUi(this);
    ifstream fin("C:\\mole\\map.txt");
    fin>>game1>>game2>>game3;
    fin.close();
    //init games world
    _game3.initWorld3("C:\\mole\\map3.txt");//todo
    _game2.initWorld2("C:\\mole\\map2.txt");//todo"
    _game.initWorld("C:\\mole\\map1.txt");
//-------------------timer of game1-----------------------
    //小猪的运动timer
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(pigMove()));
    //timer1->start(1000);
    //timer1->setInterval(500);

    //以下是对player时钟的初始化
    timer0 = new QTimer(this);
    connect(timer0,SIGNAL(timeout()),this,SLOT(countTime()));
    //timer0->start(100);
    //timer0->setInterval(1000);

//-------------------timer of game2-----------------------
    genefiretimer = new QTimer(this);
    connect(genefiretimer,SIGNAL(timeout()),this,SLOT(GenerateFire()));
    //genefiretimer->start(1000);

    firetimer = new QTimer(this);
        connect(firetimer,SIGNAL(timeout()),this,SLOT(MoveFire()));
        //firetimer->start(1000);

        watertimer = new QTimer(this);
        connect(watertimer,SIGNAL(timeout()),this,SLOT(MoveWater()));
        //watertimer->start(1000);

        indiantimer = new QTimer(this);
        connect(indiantimer,SIGNAL(timeout()),this,SLOT(MoveIndian()));
        //indiantimer->start(1000);
//-------------------timer of game3-----------------------
     fishtimer = new QTimer(this);
    connect( fishtimer,SIGNAL(timeout()),this,SLOT(fishOn()));
     fishtimer->setInterval(500);

     balloontimer = new QTimer(this);
    connect( balloontimer,SIGNAL(timeout()),this,SLOT(balloonMove()));
     balloontimer->setInterval(250);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){//TODO make up
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if(now==3){
        this->_game3.show(pa);//todo?
    }else if(now==2){
        this->_game2.show(pa);
    }
    else if(now==1){
        this->_game.show(pa);
    }
    pa->end();
    delete pa;
}

void MainWindow::keyPressEvent(QKeyEvent *e)//TODO make up
{
    //direction = 1,2,3,4 for 上右下左
    if(e->key() == Qt::Key_A)
    {
        if(this->now==3){
            this->_game3.handlePlayerMove(4,1);
            if(this->_game3.getFishCount()==4){
                this->_game3.handleFishMove(4,1);
            }
        }
        else if(this->now==1){
            this->_game.handlePlayerMove(3,1);
            dir = 3;
        }
    }
    else if(e->key() == Qt::Key_D)
    {
        if(this->now==3){
            this->_game3.handlePlayerMove(2,1);
            if(this->_game3.getFishCount()==4){
                this->_game3.handleFishMove(2,1);
            }
        }
        else if(this->now==1){
            this->_game.handlePlayerMove(4,1);
            dir = 4;
        }
    }
    else if(e->key() == Qt::Key_W)
    {
        if(this->now==1){
            this->_game.handlePlayerMove(1,1);
            dir = 1;
        }
        else if(this->now==2){
            this->_game2.mole2water();
            if(this->_game2.handleWaterMove()==true)
            {
                finishGame2(1);
            }
        }
        else if(this->now==3){
        this->_game3.handlePlayerMove(1,1);
        if(this->_game3.getFishCount()==4){
            this->_game3.handleFishMove(1,1);
        }
        }

    }
    else if(e->key() == Qt::Key_S)
    {
        if(this->now==3){
         this->_game3.handlePlayerMove(3,1);
        if(this->_game3.getFishCount()==4){
            this->_game3.handleFishMove(3,1);
            }
        }
        else if(this->now==1){
            this->_game.handlePlayerMove(2,1);
             dir = 2;
        }
    }
    else if(e->key() == Qt::Key_B)//TODO 存档
    {
        this->save();
    }
    else if(e->key() == Qt::Key_F)//may change
    {
        if(this->now==3){
        this->fishing();
        this->_game3.putFish();
        this->_game3.memeTalk(this);
        }
    }
    else if(e->key() == Qt::Key_I)
    {
        if(this->now==2){
        this->_game2.mole2indian();
       if(this->_game2.handleIndianMove()==true)
        {
            finishGame2(1);
        }
        }
    }
    else if(e->key() == Qt::Key_Space){//炸弹
        this->_game.playerPlaceBomb();
    }
    else if(e->key() == Qt::Key_N){
        if(this->_game3.getFnsh_rding_rule() != 3)
            this->_game3.fnshOneDialg();
    }
    if(this->now==3){//每次都确认是否吃够糖果
        balloonFly();
    }
    checkWorld();
    this->repaint();
}

void MainWindow::checkWorld()
{
    if(now==3&&this->_game3.getPlayerX()==19&&this->_game3.getPlayerY()==10&&game2==0){
        now=2;
        playGame2BGM();
        _game3.stopBGM();
        genefiretimer->start(1000);
        firetimer->start(1000);
        watertimer->start(1000);
        indiantimer->start(1000);
        return;
    }else if(now==3&&this->_game3.getPlayerX()==19&&this->_game3.getPlayerY()==10&&game2==1){
        QMessageBox box;
        box.about(this,"Warning","你已经完成这个游戏了哦^-^");
    }
    if(now==3&&this->_game3.getPlayerX()==31&&this->_game3.getPlayerY()==10&&game1==0){
        now=1;
        playGame1BGM();
        _game3.stopBGM();
        timer1->start(1000);
        timer1->setInterval(500);
        timer0->start(100);
        timer0->setInterval(1000);
        return;
    }
    else if(now==3&&this->_game3.getPlayerX()==31&&this->_game3.getPlayerY()==10&&game1==1){
        QMessageBox box;
        box.about(this,"Warning","你已经完成这个游戏了哦^-^");
    }
}

void MainWindow::save()
{
    ofstream fout("C:\\mole\\map.txt");
    fout<<game1<<endl<<game2<<endl<<game3<<endl;
    fout.close();
    this->_game3.save("C:\\mole\\map3.txt");

}

void MainWindow::finishGame1(int result)
{
    now=3;
    _game3.playBGM();
    game1=result;
    timer1->stop();
    timer0->stop();
    if(game1){
        _game3.setmemeChange(1);
        _game3.putawayPig();
    }
    else{
        this->_game.resetGame1("C:\\mole\\map1.txt");
    }
}

void MainWindow::finishGame2(int result)
{
    now=3;
    _game3.playBGM();
    game2=result;
    genefiretimer->stop();
    firetimer->stop();
    watertimer->stop();
    indiantimer->stop();
    if(game2){
        stopGame2BGM();
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\win.mp3"));
        player->setVolume(30);
        player->play();
        QMessageBox box;
        box.about(this,"Warning","You win!");
        cout<<"heihei"<<endl;
        _game3.setmemeChange(2);
        _game3.putawayPig();
    }else{
        stopGame2BGM();
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\death.mp3"));
        player->setVolume(30);
        player->play();
        QMessageBox box;
        box.about(this,"Warning","Game Over!");
        _game2.initWorld2("C:\\mole\\map2.txt");
    }
}

void MainWindow::receivelogin()
{
    this->show();//显示主窗口
}
//-----------------game1----------------------
void MainWindow::straightMove(){
   int d = dir;
   this->_game.handlePlayerMove(d,1);
   if(this->_game.getPlayer().getIsDead()==1)
   {
       QMessageBox box;
       box.about(this,"Warning","Game Over!");
       finishGame1(0);
   }
   this->update();
}



void MainWindow::pigMove(){
    _game.pigMove();
    if(this->_game.getPigVectorSize()==0)
    {
        QMessageBox box;
        box.about(this,"Warning","You win!");
        finishGame1(1);
    }

    if(this->_game.getPlayer().getIsDead()==1)
    {
        QMessageBox box;
        box.about(this,"Warning","Game Over!");
        finishGame1(0);
    }
    this->update();
}

void MainWindow::countAllTime(){
    seconds++;
    this->update();
}

void MainWindow::countTime(){
    count_scs++;
    this->update();
    }
//-----------------game2----------------------
void MainWindow::MoveFire(){
    if(this->_game2.handleFireMove()==true)
    {
       finishGame2(0);
        /* QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\death.mp3"));
        player->setVolume(30);
        player->play();
        QMessageBox box;
        box.about(this,"Warning","Game Over!");*/
    this->repaint();
}
}

void MainWindow::GenerateFire(){
    this->_game2.ghost2fire();
    this->repaint();
}
void MainWindow::MoveWater(){
    if(this->_game2.handleWaterMove()==true)
    {
        /*stopGame2BGM();
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\win.mp3"));
        player->setVolume(30);
        player->play();
        QMessageBox box;
        box.about(this,"Warning","You win!");*/
        finishGame2(1);
    }
    this->repaint();
}

void MainWindow::MoveIndian(){
    if(now==2&&this->_game2.handleIndianMove()==true)
    {
        /*cout<<"2"<<endl;
        stopGame2BGM();
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:\\MoleWorld\\win.mp3"));
        player->setVolume(30);
        player->play();
        QMessageBox box;
        box.about(this,"Warning","You win!");*/
        finishGame2(1);
    }
    this->repaint();
}
//-----------------------game3------------------------
void MainWindow::fishing()
{
    if(this->_game3.getPlayerX()!=12||this->_game3.getPlayerY()!=17){
        return;
    }
    fishtimer->start();
}

void MainWindow::balloonFly()
{
    if(this->_game3.getCandyCount()!=3){
        return;

    }
    _game3.setCandyCount(4);
    balloontimer->start();

}

void MainWindow::fishOn(){

    this->_game3.changeFish();
    this->repaint();
    if(_game3.getFishCount()==4){
         fishtimer->stop();
         _game3.setmemeChange(3);
         _game3.putawayPig();
    }

}

void MainWindow::balloonMove()
{
    if(!this->_game3.balloonMove()){
        balloontimer->stop();
        return;
    }
    this->repaint();
}
//----------------------temporarily useless------------
void MainWindow::randomMove(){
    int e = (1 + rand()%2)*2;
    //this->_game3.handleMonsterMove(e,1);
    this->repaint();
}
