#ifndef RPGOBJ_BR_H
#define RPGOBJ_BR_H
#include <QImage>
#include <QPainter>
#include <string>
#include "icon.h"
#include <map>
#include "rpgobj.h"
using namespace std;

class RPGObj_br: public RPGObj{
public:
    RPGObj_br(){}

    void initObj(string type);
    void show(QPainter * painter);

    bool canBomb() const{return this->_bombable;}
    void changeisEaten() {this->_is_eaten = 1;}
    bool getisEaten(int i);

protected:
    //所有坐标，单位均为游戏中的格

    bool _bombable;//是否可以被炸掉
    bool _is_eaten = 0;
};
#endif // RPGOBJ_BR_H
