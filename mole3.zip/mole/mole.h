#ifndef MOLE_H
#define MOLE_H
#include "soldier.h"
#include "weapon.h"

class Mole:public Soldier
{
public:
    Mole();
    ~Mole();
    Weapon useindian();
    Weapon usewater();
};

#endif // MOLE_H
