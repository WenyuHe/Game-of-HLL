#include "player_br.h"
#include "rpgobj_br.h"
#include"world_br.h"
#include"mainwindow.h"

//direction =1,2,3,4 for 上下左右
void Player_br::move(int direction, int steps){

    switch (direction){
        case 1:
            this->_pos_y -= steps;
            break;
        case 2:
            this->_pos_y += steps;
            break;
        case 3:
            this->_pos_x -= steps;
            break;
        case 4:
            this->_pos_x += steps;
            break;
        case 5:
            this->_pos_x = this->_pos_x;
            this->_pos_y = this->_pos_y;
            break;
    }
}

void Player_br::placeBomb(){
        placeTime = MainWindow::count_scs;
        _has_set_boom = 1;
        bomb.initObj("bomb");
        bomb.setPosX(_pos_x);
        bomb.setPosY(_pos_y+1);
        blast_h.initObj("blast_h");
        blast_h.setPosX(_pos_x - 1);
        blast_h.setPosY(_pos_y + 1);
        blast_v.initObj("blast_v");
        blast_v.setPosX(_pos_x);
        blast_v.setPosY(_pos_y);
}


