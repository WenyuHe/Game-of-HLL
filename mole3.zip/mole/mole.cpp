#include "mole.h"

Mole::Mole()
{

}


Mole::~Mole()
{

}

Weapon Mole::usewater(){
    Weapon water("water",this->getpower());
    return water;
}
Weapon Mole::useindian(){
    Weapon indian("indian1",this->getpower());
    return indian;
}
