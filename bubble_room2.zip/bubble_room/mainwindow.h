#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QImage>
#include<QPainter>
#include<QKeyEvent>
#include<QTimer>
#include"world_br.h"
#include<QLabel>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);
    void straightMove();
    static int count_scs;

protected slots:
    void countTime();
    void pigMove();

private:
    Ui::MainWindow *ui;
    World_br _game;
    QTimer *timer0;
    QTimer *timer1;
    QTimer *timer2;
    QTimer *timer3;
    int dir;
    QLabel *label;
};

#endif // MAINWINDOW_H
