#include "rpgobj_br.h"
#include <iostream>

void RPGObj_br::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if (type.compare("player_br")==0){
        this->_coverable = true;
        this->_bombable = true;
        this->_eatable = false;
    }
    else if (type.compare("pig1_br")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("pig2_br")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("pig3_br")==0){
        this->_coverable = true;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("sofa")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }

    else if (type.compare("chair")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("frige")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("bomb")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("blast_h")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("blast_v")==0){
        this->_coverable = false;
        this->_bombable = false;
         this->_eatable = false;
    }
    else if (type.compare("cake")==0){
        this->_coverable = true;
        this->_bombable = false;
         this->_eatable = true;
    }
    else if (type.compare("desk")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else if (type.compare("shelf")==0){
        this->_coverable = false;
        this->_bombable = true;
         this->_eatable = false;
    }
    else{
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = Icon::findIcon(type);
    QImage all;
    all.load("C:\\mole\\material.png");
    this->_pic = all.copy(QRect(_icon.getSrcX()*Icon::GRID_SIZE, _icon.getSrcY()*Icon::GRID_SIZE, _icon.getWidth()*Icon::GRID_SIZE, _icon.getHeight()*Icon::GRID_SIZE));
}

void RPGObj_br::show(QPainter * pa){
    int gSize = Icon::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}


