#ifndef MYDIALOG_H
#define MYDIALOG_H

#include <QDialog>
#include <QImage>
#include <QPainter>
namespace Ui {
class Mydialog;
}

class Mydialog : public QDialog
{
    Q_OBJECT

public:
    explicit Mydialog(QWidget *parent = 0);
    ~Mydialog();
    void paintEvent(QPaintEvent *e);
private slots:
    void on_pushButton_clicked();//与login关联的槽函数
    void on_pushButton_2_clicked();//与exit关联的槽函数
signals:
    void showmainwindow();//显示主窗口信号
    void quit();//退出信号
private:
    Ui::Mydialog *ui;
    QImage _bg;
};

#endif // MYDIALOG_H
