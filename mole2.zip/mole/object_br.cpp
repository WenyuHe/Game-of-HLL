#include"object_br.h"


bool Object_br::getHasExploded(){
    return this->_has_exploded;
}
